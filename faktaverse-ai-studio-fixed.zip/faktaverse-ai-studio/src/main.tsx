import React from 'react';
import { createRoot } from 'react-dom/client';
import './index.css';
import { App } from './App';
import { ProjectProvider } from './state/useProject';

createRoot(document.getElementById('root')!).render(
  <ProjectProvider>
    <App />
  </ProjectProvider>,
);
