import type { Project } from '../engine/types';

async function j<T>(res: Response): Promise<T> {
  if (!res.ok) {
    let msg = `${res.status} ${res.statusText}`;
    try { msg = (await res.json()).error ?? msg; } catch { /* abaikan */ }
    throw new Error(msg);
  }
  return res.json() as Promise<T>;
}
const post = (url: string, body?: unknown) => fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body ?? {}) });

export interface ProjectSummary { id: string; name: string; updatedAt: string; preset: string; assets: number; scenes: number; seconds: number; thumb: string | null }
export interface Caps { transcribe: boolean; keywords: boolean; cutout: boolean; ffmpeg: boolean; currentProject: string | null }

export const api = {
  caps: () => fetch('/api/capabilities').then((r) => j<Caps>(r)),
  list: () => fetch('/api/projects').then((r) => j<ProjectSummary[]>(r)),
  create: (name: string) => post('/api/projects', { name }).then((r) => j<Project>(r)),
  get: (id: string) => fetch(`/api/projects/${id}`).then((r) => j<Project>(r)),
  save: (p: Project) => fetch(`/api/projects/${p.id}`, { method: 'PUT', headers: { 'content-type': 'application/json' }, body: JSON.stringify(p) }).then((r) => j<{ ok: boolean; missing: string[] }>(r)),
  remove: (id: string) => fetch(`/api/projects/${id}`, { method: 'DELETE' }).then((r) => j<{ ok: boolean }>(r)),
  deleteAsset: (id: string, aid: string) => fetch(`/api/projects/${id}/assets/${aid}`, { method: 'DELETE' }).then((r) => j<Project>(r)),
  deleteAudio: (id: string, kind: 'music' | 'narration') => fetch(`/api/projects/${id}/${kind}`, { method: 'DELETE' }).then((r) => j<Project>(r)),
  transcribe: (id: string) => post(`/api/projects/${id}/transcribe`).then((r) => j<Project>(r)),
  subtitles: (id: string, body: { script?: string; srt?: string }) => post(`/api/projects/${id}/subtitles`, body).then((r) => j<Project>(r)),
  cutout: (id: string, aid: string) => post(`/api/projects/${id}/cutout/${aid}`).then((r) => j<Project>(r)),
  importProject: (p: unknown) => post('/api/import', p).then((r) => j<{ project: Project; missing: string[] }>(r)),
  /** Upload dengan progres (XHR, karena fetch belum punya progres upload) */
  upload(id: string, kind: 'media' | 'music' | 'narration', files: File[], onProgress: (pct: number) => void): Promise<{ project: Project; errors: string[] }> {
    return new Promise((resolve, reject) => {
      const fd = new FormData();
      files.forEach((f) => fd.append('files', f));
      const xhr = new XMLHttpRequest();
      xhr.open('POST', `/api/projects/${id}/upload/${kind}`);
      xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
      xhr.onload = () => {
        try {
          const body = JSON.parse(xhr.responseText);
          xhr.status >= 200 && xhr.status < 300 ? resolve(body) : reject(new Error(body.error ?? `Upload gagal (${xhr.status})`));
        } catch { reject(new Error(`Upload gagal (${xhr.status})`)); }
      };
      xhr.onerror = () => reject(new Error('Koneksi ke server terputus. Pastikan port 3001 berjalan dan di-forward.'));
      xhr.send(fd);
    });
  },
};
