import { Easing } from 'remotion';
import type { TransitionType } from '../engine/types';

export interface EntranceStyle { opacity: number; transform: string; filter?: string }

/** Gaya masuk sebuah scene pada frame lokal f dengan panjang transisi T. Scene sebelumnya tetap tampil di bawahnya. */
export function entrance(type: TransitionType, f: number, T: number): EntranceStyle {
  if (T <= 0 || f >= T || type === 'cut' || type === 'flash' || type === 'glitch') return { opacity: 1, transform: 'none' };
  const p = Math.min(1, Math.max(0, f / T));
  const out = Easing.out(Easing.cubic)(p);
  switch (type) {
    case 'fade': return { opacity: p, transform: 'none' };
    case 'slide': return { opacity: 1, transform: `translateX(${((1 - out) * 100).toFixed(2)}%)` };
    case 'whip': return { opacity: 1, transform: `translateX(${((1 - out) * 120).toFixed(2)}%) scale(${(1 + (1 - out) * 0.12).toFixed(3)})`, filter: `blur(${((1 - out) * 26).toFixed(1)}px)` };
    case 'zoom': return { opacity: out, transform: `scale(${(1.7 - 0.7 * out).toFixed(3)})`, filter: `blur(${((1 - out) * 10).toFixed(1)}px)` };
    case 'spin': return { opacity: out, transform: `rotate(${((1 - out) * 28).toFixed(2)}deg) scale(${(0.55 + 0.45 * out).toFixed(3)})` };
    default: return { opacity: 1, transform: 'none' };
  }
}
