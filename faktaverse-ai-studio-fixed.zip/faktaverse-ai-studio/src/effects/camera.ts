import { Easing, interpolate } from 'remotion';
import type { CameraMove } from '../engine/types';

const ease = Easing.inOut(Easing.cubic);
const clamp = (v: number, a = 0, b = 1) => Math.min(b, Math.max(a, v));

export interface CamResult { transform: string; filter?: string }

/**
 * Semua gerak kamera adalah fungsi murni dari frame (deterministik, aman untuk render paralel).
 * k = intensitas 0..1, shake = basis getaran preset 0..1
 */
export function camera(move: CameraMove, f: number, dur: number, k: number, seed: number, shake: number): CamResult {
  const p = clamp(f / Math.max(1, dur));
  const dir = seed % 2 === 0 ? 1 : -1;
  let s = 1, x = 0, y = 0, r = 0;
  let filter: string | undefined;
  const amp = 0.4 + k * 0.6;
  switch (move) {
    case 'zoomIn': s = 1.04 + 0.2 * amp * ease(p); break;
    case 'zoomOut': s = 1.04 + 0.2 * amp * (1 - ease(p)); break;
    case 'punch': {
      const pulse = (f0: number) => Math.max(0, 1 - Math.abs(f - f0) / 7) * (f >= f0 ? 1 : 0);
      s = 1.05 + 0.08 * ease(p) + 0.16 * amp * (pulse(0) + pulse(Math.round(dur * 0.55)) * 0.6);
      break;
    }
    case 'shake': {
      s = 1.1;
      x = (Math.sin(f * 1.9 + seed) * 14 + Math.sin(f * 4.3 + seed * 2) * 7) * amp;
      y = (Math.cos(f * 2.3 + seed) * 12 + Math.sin(f * 5.1 + seed) * 6) * amp;
      r = Math.sin(f * 1.3 + seed) * 0.8 * amp;
      break;
    }
    case 'panH': s = 1.16; x = dir * interpolate(ease(p), [0, 1], [-70, 70]); break;
    case 'panV': s = 1.16; y = dir * interpolate(ease(p), [0, 1], [-80, 80]); break;
    case 'rotate': s = 1.14; r = interpolate(ease(p), [0, 1], [-3.5, 3.5]) * dir * amp; break;
    case 'whip': {
      const q = clamp(f / 9);
      const e = Easing.out(Easing.cubic)(q);
      s = 1.12; x = (1 - e) * 220 * dir;
      filter = `blur(${((1 - e) * 22 * amp).toFixed(1)}px)`;
      break;
    }
    case 'parallax': s = 1.03; break;
    case 'still': default: break;
  }
  if (shake > 0 && move !== 'shake') {
    const a = shake * k * 5;
    x += Math.sin(f * 2.7 + seed) * a;
    y += Math.cos(f * 3.1 + seed) * a;
    s *= 1 + shake * 0.01;
  }
  return { transform: `translate(${x.toFixed(2)}px, ${y.toFixed(2)}px) rotate(${r.toFixed(3)}deg) scale(${s.toFixed(4)})`, filter };
}
