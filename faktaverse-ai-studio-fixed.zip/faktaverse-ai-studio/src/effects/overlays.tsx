import React from 'react';
import { AbsoluteFill, interpolate } from 'remotion';

export const Grain: React.FC<{ frame: number; amount: number }> = ({ frame, amount }) => {
  if (amount <= 0.01) return null;
  // Render kecil lalu diperbesar: murah dan deterministik (seed = frame)
  return (
    <AbsoluteFill style={{ mixBlendMode: 'overlay', opacity: Math.min(0.6, amount * 1.4), pointerEvents: 'none' }}>
      <svg viewBox="0 0 270 480" preserveAspectRatio="none" style={{ width: '100%', height: '100%' }}>
        <filter id="fv-grain">
          <feTurbulence type="fractalNoise" baseFrequency="0.9" numOctaves="2" seed={frame % 24} stitchTiles="stitch" />
          <feColorMatrix type="saturate" values="0" />
        </filter>
        <rect width="270" height="480" filter="url(#fv-grain)" />
      </svg>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC<{ amount: number }> = ({ amount }) =>
  amount <= 0.01 ? null : (
    <AbsoluteFill style={{ background: `radial-gradient(ellipse at center, rgba(0,0,0,0) 45%, rgba(0,0,0,${Math.min(0.9, amount)}) 100%)`, pointerEvents: 'none' }} />
  );

export const Flash: React.FC<{ frame: number; len?: number; color?: string }> = ({ frame, len = 7, color = '#fff' }) =>
  frame >= len ? null : <AbsoluteFill style={{ background: color, opacity: interpolate(frame, [0, len], [0.85, 0], { extrapolateRight: 'clamp' }), pointerEvents: 'none' }} />;

const h = (n: number) => { const x = Math.sin(n * 127.1 + 311.7) * 43758.5453; return x - Math.floor(x); };

export const FilterDefs: React.FC = () => (
  <svg width="0" height="0" style={{ position: 'absolute' }}>
    <filter id="fv-r"><feColorMatrix type="matrix" values="1 0 0 0 0  0 0 0 0 0  0 0 0 0 0  0 0 0 1 0" /></filter>
    <filter id="fv-g"><feColorMatrix type="matrix" values="0 0 0 0 0  0 1 0 0 0  0 0 0 0 0  0 0 0 1 0" /></filter>
    <filter id="fv-b"><feColorMatrix type="matrix" values="0 0 0 0 0  0 0 0 0 0  0 0 1 0 0  0 0 0 1 0" /></filter>
  </svg>
);

/** RGB split + glitch slice. Hanya merender 4 salinan saat aktif, selain itu children biasa. */
export const GlitchWrap: React.FC<{ active: boolean; frame: number; seed: number; strength?: number; children: React.ReactNode }> = ({ active, frame, seed, strength = 1, children }) => {
  if (!active) return <>{children}</>;
  const dx = (h(frame * 3 + seed) * 2 - 1) * 26 * strength;
  const dy = (h(frame * 5 + seed) * 2 - 1) * 6 * strength;
  const sliceY = h(frame + seed) * 1500;
  const sliceH = 80 + h(frame * 7 + seed) * 180;
  const sx = (h(frame * 11 + seed) * 2 - 1) * 90 * strength;
  const layer = (f: string, tx: number, ty: number) => (
    <AbsoluteFill style={{ filter: `url(#${f})`, transform: `translate(${tx}px, ${ty}px)`, mixBlendMode: 'screen' }}>{children}</AbsoluteFill>
  );
  return (
    <AbsoluteFill style={{ background: '#000' }}>
      {layer('fv-r', dx, dy)}
      {layer('fv-g', 0, 0)}
      {layer('fv-b', -dx, -dy)}
      <AbsoluteFill style={{ clipPath: `inset(${sliceY}px 0 ${Math.max(0, 1920 - sliceY - sliceH)}px 0)`, transform: `translateX(${sx}px)` }}>{children}</AbsoluteFill>
    </AbsoluteFill>
  );
};
