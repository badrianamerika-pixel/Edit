import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react';
import type { Project } from '../engine/types';
import { api } from '../services/api';

export type SaveStatus = 'idle' | 'dirty' | 'saving' | 'saved' | 'error';

interface Ctx {
  project: Project | null;
  status: SaveStatus;
  statusMsg: string;
  open: (id: string) => Promise<void>;
  close: () => void;
  /** perubahan lokal → autosave */
  update: (fn: (p: Project) => Project) => void;
  /** ganti seluruh proyek dari server (mis. setelah upload) */
  replace: (p: Project) => void;
  saveNow: () => Promise<void>;
  pause: (v: boolean) => void;
}
const C = createContext<Ctx>(null as unknown as Ctx);
export const useProject = () => useContext(C);

export const ProjectProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [project, setProject] = useState<Project | null>(null);
  const [status, setStatus] = useState<SaveStatus>('idle');
  const [statusMsg, setMsg] = useState('');
  const timer = useRef<ReturnType<typeof setTimeout>>();
  const paused = useRef(false);
  const latest = useRef<Project | null>(null);
  latest.current = project;

  const doSave = useCallback(async () => {
    const p = latest.current;
    if (!p || paused.current) return;
    setStatus('saving');
    try {
      const r = await api.save(p);
      setStatus('saved');
      setMsg(r.missing.length ? `Peringatan: file hilang di disk: ${r.missing.join(', ')}` : '');
    } catch (e) { setStatus('error'); setMsg((e as Error).message); }
  }, []);

  const schedule = useCallback(() => {
    setStatus('dirty');
    clearTimeout(timer.current);
    timer.current = setTimeout(doSave, 900);
  }, [doSave]);

  // Pemulihan: buka proyek terakhir jika halaman dimuat ulang
  useEffect(() => {
    const last = localStorage.getItem('fv:last');
    if (last) api.get(last).then(setProject).catch(() => localStorage.removeItem('fv:last'));
  }, []);
  // Peringatan sebelum menutup tab dengan perubahan belum tersimpan
  useEffect(() => {
    const h = (e: BeforeUnloadEvent) => { if (status === 'dirty' || status === 'saving') { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', h);
    return () => window.removeEventListener('beforeunload', h);
  }, [status]);

  const value: Ctx = {
    project, status, statusMsg,
    open: async (id) => { const p = await api.get(id); localStorage.setItem('fv:last', id); setProject(p); setStatus('saved'); setMsg(''); },
    close: () => { setProject(null); localStorage.removeItem('fv:last'); setStatus('idle'); },
    update: (fn) => { setProject((p) => (p ? fn(p) : p)); schedule(); },
    replace: (p) => { setProject(p); setStatus('saved'); },
    saveNow: async () => { clearTimeout(timer.current); await doSave(); },
    pause: (v) => { paused.current = v; if (v) clearTimeout(timer.current); },
  };
  return <C.Provider value={value}>{children}</C.Provider>;
};
