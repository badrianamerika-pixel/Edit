import React from 'react';
import { Img, OffthreadVideo, staticFile } from 'remotion';
import type { Asset } from '../engine/types';

/**
 * Preview (browser): base = "/files/<projectId>/" dan suara dari "/sounds/..".
 * Render (Codespaces): base undefined -> staticFile() dari folder publik sementara yang dibuat scripts/render.ts.
 */
export function resolve(path: string, base?: string): string {
  if (/^(https?:|data:|blob:)/.test(path)) return path;
  if (base === undefined) return staticFile(path);
  if (path.startsWith('sounds/')) return '/' + path;
  return base + path;
}

export const Media: React.FC<{ asset: Asset; base?: string; fit?: 'cover' | 'contain'; style?: React.CSSProperties; useCutout?: boolean }> = ({ asset, base, fit = 'cover', style, useCutout }) => {
  const st: React.CSSProperties = { width: '100%', height: '100%', objectFit: fit, ...style };
  if (useCutout && asset.cutout) return <Img src={resolve(asset.cutout, base)} style={st} />;
  if (asset.kind === 'video') return <OffthreadVideo src={resolve(asset.file, base)} muted style={st} />;
  return <Img src={resolve(asset.file, base)} style={st} />;
};
