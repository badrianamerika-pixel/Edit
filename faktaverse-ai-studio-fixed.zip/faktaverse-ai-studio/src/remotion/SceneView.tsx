import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { Asset, Scene } from '../engine/types';
import type { Preset } from '../engine/presets';
import type { TypographyConfig } from '../engine/types';
import { camera } from '../effects/camera';
import { entrance } from '../effects/transitions';
import { Flash, GlitchWrap } from '../effects/overlays';
import { Kinetic } from '../typography/Kinetic';
import { LayoutView } from './layouts';

export const SceneView: React.FC<{ scene: Scene; assets: Asset[]; base?: string; frame: number; visible: number; preset: Preset; typo: TypographyConfig; globalIntensity: number }> = ({ scene, assets, base, frame, visible, preset, typo, globalIntensity }) => {
  const list = scene.assetIds.map((id) => assets.find((a) => a.id === id)).filter(Boolean) as Asset[];
  if (!list.length) return <AbsoluteFill style={{ background: preset.bg }} />;
  const k = scene.intensity * (0.5 + globalIntensity * 0.5);
  const cam = camera(scene.camera, frame, visible, k, scene.seed, preset.shake * globalIntensity);
  const ent = entrance(scene.transition, frame, scene.transitionFrames);
  const glitchActive = (scene.glitch || scene.transition === 'glitch') && frame < Math.max(6, scene.transitionFrames);
  const typoLayout = scene.layout === 'typo';
  const font = typo.font === 'system' ? 'system' : typo.font === 'anton' && preset.font === 'montserrat' ? 'anton' : typo.font;
  const textInner = scene.text ? (
    <Kinetic text={scene.text} keywords={scene.keywords} style={typoLayout && scene.textStyle === 'label' ? 'pop' : scene.textStyle} font={font}
      frame={frame - 3} base={(typoLayout ? 230 : 120) * typo.sizeScale} maxWidth={typoLayout ? 960 : 900} maxHeight={typoLayout ? 900 : 360}
      accent={preset.accent} accent2={preset.accent2} seed={scene.seed} />
  ) : null;
  return (
    <AbsoluteFill style={{ opacity: ent.opacity, transform: ent.transform, filter: ent.filter }}>
      <GlitchWrap active={glitchActive} frame={frame} seed={scene.seed} strength={0.6 + k}>
        <AbsoluteFill style={{ filter: preset.grade }}>
          <AbsoluteFill style={{ transform: cam.transform, filter: cam.filter, transformOrigin: '50% 50%' }}>
            <LayoutView layout={scene.layout} assets={list} base={base} frame={frame} dur={visible} seed={scene.seed} preset={preset} intensity={k} text={scene.text} />
          </AbsoluteFill>
        </AbsoluteFill>
      </GlitchWrap>
      {textInner && (
        <AbsoluteFill style={{ justifyContent: typoLayout ? 'center' : 'flex-end', alignItems: 'center', paddingBottom: typoLayout ? 0 : 400 }}>{textInner}</AbsoluteFill>
      )}
      {scene.flash && <Flash frame={frame} />}
    </AbsoluteFill>
  );
};
