import React, { useMemo } from 'react';
import { AbsoluteFill, Audio, Sequence, interpolate, useCurrentFrame, useVideoConfig } from 'remotion';
import { PRESETS } from '../engine/presets';
import { FPS, type Project } from '../engine/types';
import { Captions } from '../typography/Captions';
import { FONT_STACK, useFontsReady } from '../typography/fonts';
import { FilterDefs, Grain, Vignette } from '../effects/overlays';
import { resolve } from './assets';
import { SceneView } from './SceneView';

export interface MainProps { project: Project; base?: string }

const SFX_FRAMES = 45;

export const Main: React.FC<MainProps> = ({ project, base }) => {
  useFontsReady();
  const frame = useCurrentFrame();
  const { fps, durationInFrames } = useVideoConfig();
  const preset = PRESETS[project.preset];
  const { audio, typography: typo } = project;

  const timeline = useMemo(() => {
    let start = 0;
    return project.scenes.map((s, i) => {
      const next = project.scenes[i + 1];
      const tail = next ? next.transitionFrames : 0;
      const item = { scene: s, start, visible: s.durationFrames + tail };
      start += s.durationFrames;
      return item;
    });
  }, [project.scenes]);

  const totalSec = durationInFrames / fps;
  const narrEnd = project.narration ? project.narration.durationSec * fps : 0;
  const musicVolume = (f: number) => {
    const fi = interpolate(f, [0, audio.fadeInSec * fps], [0, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
    const fo = interpolate(f, [durationInFrames - audio.fadeOutSec * fps, durationInFrames], [1, 0], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' });
    // ducking: narasi selalu diprioritaskan; musik kembali naik perlahan setelah narasi selesai
    const duck = project.narration ? interpolate(f, [narrEnd - fps * 0.2, narrEnd + fps], [audio.duckTo, 1], { extrapolateLeft: 'clamp', extrapolateRight: 'clamp' }) : 1;
    return Math.max(0, Math.min(1, audio.musicVolume * fi * fo * duck));
  };

  return (
    <AbsoluteFill style={{ background: '#000', fontFamily: FONT_STACK[typo.font] }}>
      <FilterDefs />
      {timeline.map(({ scene, start, visible }) => (
        <Sequence key={scene.id} from={start} durationInFrames={visible} layout="none">
          <SceneSeq scene={scene} project={project} base={base} visible={visible} preset={preset} start={start} />
        </Sequence>
      ))}
      <Grain frame={frame} amount={preset.grain * project.intensity} />
      <Vignette amount={preset.vignette} />
      {project.mode === 'narration' && project.subtitles.length > 0 && (
        <Captions subtitles={project.subtitles} frame={frame} fps={fps || FPS} typo={typo} preset={preset} />
      )}
      {typo.showTitleBar && project.title && (
        <AbsoluteFill style={{ top: 170, bottom: 'auto', height: 140, alignItems: 'center', justifyContent: 'center' }}>
          <div style={{ color: '#fff', fontFamily: FONT_STACK.montserrat, fontWeight: 800, fontSize: 46, textAlign: 'center', maxWidth: 900, textShadow: '0 3px 14px rgba(0,0,0,.8)', WebkitTextStroke: '1px rgba(0,0,0,.5)' }}>{project.title}</div>
        </AbsoluteFill>
      )}
      {project.music && (
        <Sequence from={0} layout="none">
          <Audio src={resolve(project.music.file, base)} volume={musicVolume} loop={project.music.durationSec < totalSec} />
        </Sequence>
      )}
      {project.narration && (
        <Sequence from={0} layout="none">
          <Audio src={resolve(project.narration.file, base)} volume={audio.narrationVolume} />
        </Sequence>
      )}
      {audio.sfxEnabled && timeline.filter((t) => t.scene.sfx !== 'none').map(({ scene, start }) => (
        <Sequence key={'sfx' + scene.id} from={start} durationInFrames={SFX_FRAMES} layout="none">
          <Audio src={resolve(`sounds/${scene.sfx}.wav`, base)} volume={audio.sfxVolume * (0.55 + 0.45 * scene.intensity)} />
        </Sequence>
      ))}
    </AbsoluteFill>
  );
};

const SceneSeq: React.FC<{ scene: Project['scenes'][number]; project: Project; base?: string; visible: number; preset: (typeof PRESETS)[keyof typeof PRESETS]; start: number }> = ({ scene, project, base, visible, preset }) => {
  const frame = useCurrentFrame();
  return <SceneView scene={scene} assets={project.assets} base={base} frame={frame} visible={visible} preset={preset} typo={project.typography} globalIntensity={project.intensity} />;
};
