import React from 'react';
import { AbsoluteFill, Easing, interpolate, spring, useVideoConfig } from 'remotion';
import type { Asset, Layout } from '../engine/types';
import type { Preset } from '../engine/presets';
import { Media } from './assets';

export interface LayoutProps {
  assets: Asset[];
  base?: string;
  frame: number;
  dur: number;
  seed: number;
  preset: Preset;
  intensity: number;
  text?: string;
}

const W = 1080, H = 1920;

function useIn(frame: number, delay: number, damping = 12) {
  const { fps } = useVideoConfig();
  return spring({ frame: frame - delay, fps, config: { damping, stiffness: 160, mass: 0.7 } });
}

const Card: React.FC<{ asset: Asset; base?: string; x: number; y: number; w: number; h: number; rot: number; frame: number; delay: number; from?: 'left' | 'right' | 'bottom' | 'top' | 'scale'; border?: number; shadow?: string; bob?: number; seed?: number; radius?: number; fit?: 'cover' | 'contain' }> = ({ asset, base, x, y, w, h, rot, frame, delay, from = 'scale', border = 0, shadow = '0 30px 60px rgba(0,0,0,.55)', bob = 0, seed = 0, radius = 28, fit = 'cover' }) => {
  const s = useIn(frame, delay);
  const off = (1 - s);
  const tx = from === 'left' ? -off * 900 : from === 'right' ? off * 900 : 0;
  const ty = from === 'top' ? -off * 1200 : from === 'bottom' ? off * 1200 : 0;
  const sc = from === 'scale' ? 0.3 + 0.7 * s : 1;
  const bobY = bob ? Math.sin((frame + seed) / 14) * bob : 0;
  const bobR = bob ? Math.cos((frame + seed) / 17) * bob * 0.08 : 0;
  return (
    <div style={{ position: 'absolute', left: x, top: y, width: w, height: h, transform: `translate(${tx}px, ${ty + bobY}px) rotate(${rot + bobR + off * (from === 'scale' ? -8 : 0)}deg) scale(${sc})`, opacity: Math.min(1, s * 2), borderRadius: radius, overflow: 'hidden', border: border ? `${border}px solid #fff` : undefined, boxShadow: shadow, background: '#000' }}>
      <Media asset={asset} base={base} fit={fit} />
    </div>
  );
};

const Backdrop: React.FC<{ asset?: Asset; base?: string; preset: Preset; blur?: number; dim?: number; frame?: number }> = ({ asset, base, preset, blur = 40, dim = 0.55, frame = 0 }) => (
  <AbsoluteFill style={{ background: `linear-gradient(160deg, ${preset.bg}, #000)` }}>
    {asset && (
      <AbsoluteFill style={{ filter: `blur(${blur}px) brightness(${dim})`, transform: `scale(${1.35 + Math.sin(frame / 40) * 0.03})` }}>
        <Media asset={asset} base={base} />
      </AbsoluteFill>
    )}
  </AbsoluteFill>
);

const Starburst: React.FC<{ color: string; frame: number; size?: number; cx: number; cy: number }> = ({ color, frame, size = 1100, cx, cy }) => {
  const n = 28, pts: string[] = [];
  for (let i = 0; i < n * 2; i++) {
    const a = (i / (n * 2)) * Math.PI * 2;
    const r = (i % 2 ? 0.55 : 1) * (size / 2);
    pts.push(`${(size / 2 + Math.cos(a) * r).toFixed(1)},${(size / 2 + Math.sin(a) * r).toFixed(1)}`);
  }
  return (
    <svg width={size} height={size} style={{ position: 'absolute', left: cx - size / 2, top: cy - size / 2, transform: `rotate(${frame * 1.2}deg)` }}>
      <polygon points={pts.join(' ')} fill={color} />
    </svg>
  );
};

const Halftone: React.FC<{ color: string }> = ({ color }) => (
  <AbsoluteFill style={{ backgroundImage: `radial-gradient(${color} 22%, transparent 24%)`, backgroundSize: '36px 36px', opacity: 0.25 }} />
);

const Tag: React.FC<{ label: string; color: string; frame: number; x: number; y: number; rot?: number }> = ({ label, color, frame, x, y, rot = -3 }) => {
  const s = useIn(frame, 6, 9);
  return (
    <div style={{ position: 'absolute', left: x, top: y, transform: `rotate(${rot}deg) scale(${s})`, background: color, color: '#fff', fontFamily: "'Anton', Impact, sans-serif", fontSize: 54, padding: '8px 26px', letterSpacing: 2, boxShadow: '6px 6px 0 rgba(0,0,0,.5)' }}>{label}</div>
  );
};

export const LayoutView: React.FC<LayoutProps & { layout: Layout }> = (props) => {
  const { layout, assets, base, frame, dur, seed, preset, intensity, text } = props;
  const a = assets;
  const a0 = a[0];
  const a1 = a[1] ?? a[0];
  const a2 = a[2] ?? a[1] ?? a[0];
  const flip = seed % 2 === 0 ? 1 : -1;
  switch (layout) {
    case 'hero':
      return <AbsoluteFill><Media asset={a0} base={base} /></AbsoluteFill>;
    case 'blurbg': {
      const s = useIn(frame, 0, 14);
      return (
        <AbsoluteFill>
          <Backdrop asset={a0} base={base} preset={preset} frame={frame} />
          <div style={{ position: 'absolute', left: 40, right: 40, top: 300, bottom: 420, borderRadius: 36, overflow: 'hidden', boxShadow: '0 40px 80px rgba(0,0,0,.6)', transform: `scale(${0.9 + 0.1 * s})` }}>
            <Media asset={a0} base={base} fit="contain" style={{ background: 'rgba(0,0,0,.25)' }} />
          </div>
        </AbsoluteFill>
      );
    }
    case 'double':
      return (
        <AbsoluteFill style={{ background: `linear-gradient(180deg, ${preset.bg}, #000)` }}>
          <Card asset={a0} base={base} x={70} y={190} w={940} h={760} rot={-2 * flip} frame={frame} delay={0} from={flip > 0 ? 'left' : 'right'} border={10} />
          <Card asset={a1} base={base} x={70} y={990} w={940} h={760} rot={2 * flip} frame={frame} delay={5} from={flip > 0 ? 'right' : 'left'} border={10} />
        </AbsoluteFill>
      );
    case 'triple':
      return (
        <AbsoluteFill style={{ background: `linear-gradient(160deg, ${preset.bg}, #000)` }}>
          <Halftone color={preset.accent} />
          <Card asset={a0} base={base} x={80} y={170} w={920} h={820} rot={-2 * flip} frame={frame} delay={0} from="top" border={10} />
          <Card asset={a1} base={base} x={70} y={1040} w={470} h={620} rot={3 * flip} frame={frame} delay={5} from="left" border={10} />
          <Card asset={a2} base={base} x={560} y={1090} w={450} h={600} rot={-4 * flip} frame={frame} delay={9} from="right" border={10} />
        </AbsoluteFill>
      );
    case 'floating':
      return (
        <AbsoluteFill>
          <Backdrop asset={a0} base={base} preset={preset} frame={frame} blur={50} dim={0.45} />
          <Card asset={a0} base={base} x={90} y={250} w={640} h={880} rot={-6 * flip} frame={frame} delay={0} bob={14} seed={seed} border={8} />
          <Card asset={a1} base={base} x={420} y={760} w={560} h={760} rot={7 * flip} frame={frame} delay={4} bob={18} seed={seed + 40} border={8} />
          <Card asset={a2} base={base} x={140} y={1180} w={420} h={520} rot={-3 * flip} frame={frame} delay={8} bob={12} seed={seed + 90} border={8} />
        </AbsoluteFill>
      );
    case 'tilted':
      return (
        <AbsoluteFill style={{ background: preset.accent }}>
          <Halftone color="#000" />
          <Card asset={a0} base={base} x={60} y={230} w={820} h={1080} rot={-9 * flip} frame={frame} delay={0} from="left" border={18} radius={10} />
          <Card asset={a1} base={base} x={300} y={760} w={720} h={940} rot={8 * flip} frame={frame} delay={6} from="right" border={18} radius={10} />
        </AbsoluteFill>
      );
    case 'cutout': {
      const s = useIn(frame, 2, 9);
      const hasCut = !!a0.cutout;
      return (
        <AbsoluteFill>
          <Backdrop asset={a0} base={base} preset={preset} frame={frame} blur={30} dim={0.35} />
          <Starburst color={preset.accent2} frame={frame} cx={W / 2} cy={H / 2 - 60} />
          {hasCut ? (
            <div style={{ position: 'absolute', left: 0, top: 160, width: W, height: 1440, transform: `scale(${0.5 + 0.5 * s})`, filter: 'drop-shadow(0 30px 40px rgba(0,0,0,.6))' }}>
              <Media asset={a0} base={base} fit="contain" useCutout />
            </div>
          ) : (
            // Fallback jujur: tanpa layanan background-removal, foto dipasang sebagai kartu biasa
            <Card asset={a0} base={base} x={110} y={330} w={860} h={1120} rot={-3 * flip} frame={frame} delay={2} border={14} />
          )}
        </AbsoluteFill>
      );
    }
    case 'pip': {
      const s = useIn(frame, 8, 10);
      return (
        <AbsoluteFill>
          <Media asset={a0} base={base} />
          <div style={{ position: 'absolute', right: 50, top: 260, width: 400, height: 540, borderRadius: 30, overflow: 'hidden', border: '8px solid #fff', boxShadow: '0 20px 50px rgba(0,0,0,.6)', transform: `scale(${s}) rotate(${3 * flip}deg)` }}>
            <Media asset={a1} base={base} />
          </div>
        </AbsoluteFill>
      );
    }
    case 'multilayer': {
      const p = interpolate(frame, [0, dur], [0, 1], { extrapolateRight: 'clamp' });
      const k = 70 * flip;
      return (
        <AbsoluteFill style={{ background: preset.bg }}>
          <AbsoluteFill style={{ transform: `translateX(${(p - 0.5) * k * 0.6}px) scale(1.25)` }}><Media asset={a0} base={base} style={{ filter: 'brightness(.6)' }} /></AbsoluteFill>
          <div style={{ position: 'absolute', left: 110, top: 330, width: 860, height: 1060, borderRadius: 28, overflow: 'hidden', border: '10px solid #fff', boxShadow: '0 40px 80px rgba(0,0,0,.6)', transform: `translateX(${(p - 0.5) * k * 1.4}px)` }}><Media asset={a1} base={base} /></div>
          <div style={{ position: 'absolute', left: 560, top: 1180, width: 420, height: 520, borderRadius: 24, overflow: 'hidden', border: '8px solid #fff', boxShadow: '0 30px 60px rgba(0,0,0,.6)', transform: `translateX(${(p - 0.5) * k * 2.6}px) rotate(${4 * flip}deg)` }}><Media asset={a2} base={base} /></div>
        </AbsoluteFill>
      );
    }
    case 'typo':
      return (
        <AbsoluteFill>
          <Backdrop asset={a0} base={base} preset={preset} frame={frame} blur={22} dim={0.3} />
          <AbsoluteFill style={{ background: `linear-gradient(180deg, ${preset.accent}33, transparent 60%)` }} />
        </AbsoluteFill>
      );
    case 'poster': {
      const s = useIn(frame, 0, 12);
      return (
        <AbsoluteFill style={{ background: `linear-gradient(170deg, ${preset.accent2}, ${preset.accent})` }}>
          <Halftone color="#000" />
          <div style={{ position: 'absolute', left: 90, top: 230, width: 900, height: 1180, border: '16px solid #fff', borderRadius: 8, overflow: 'hidden', boxShadow: `22px 22px 0 #000`, transform: `rotate(${-3 * flip}deg) scale(${0.8 + 0.2 * s})`, opacity: Math.min(1, s * 2) }}>
            <Media asset={a0} base={base} />
          </div>
          {text ? null : <Tag label="FAKTA" color={preset.accent} frame={frame} x={620} y={1360} />}
        </AbsoluteFill>
      );
    }
    default:
      return <AbsoluteFill><Media asset={a0} base={base} /></AbsoluteFill>;
  }
  void Easing; void intensity;
};
