import React from 'react';
import { Composition } from 'remotion';
import { HEIGHT, newProject, totalFrames, WIDTH } from '../engine/types';
import { Main, type MainProps } from './Main';

const empty: MainProps = {
  project: newProject('empty', 'empty'),
};

export const Root: React.FC = () => (
  <Composition<MainProps>
    id="Faktaverse"
    component={Main}
    width={WIDTH}
    height={HEIGHT}
    fps={30}
    durationInFrames={30}
    defaultProps={empty}
    calculateMetadata={({ props }) => ({
      durationInFrames: totalFrames(props.project),
      fps: props.project.fps || 30,
      width: WIDTH,
      height: HEIGHT,
    })}
  />
);
