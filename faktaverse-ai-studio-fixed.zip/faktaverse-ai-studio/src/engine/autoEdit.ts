import { PRESETS, type Preset } from './presets';
import { mulberry32, pickWeighted } from './rng';
import { FPS, type Asset, type CameraMove, type Layout, type Project, type Scene, type SfxName, type TextStyle, type TransitionType } from './types';

const NEED: Record<Layout, number> = {
  hero: 1, double: 2, triple: 3, floating: 3, tilted: 2, cutout: 1, pip: 2, multilayer: 3, blurbg: 1, typo: 0, poster: 1,
};

function aspect(a: Asset) { return a.width / Math.max(1, a.height); }

/** Menentukan titik potong (detik). Prioritas: batas narasi > beat musik > grid tempo. */
export function planCuts(p: Project, preset: Preset, total: number, rand: () => number): number[] {
  const cuts: number[] = [0];
  if (p.mode === 'narration' && p.subtitles.length) {
    let start = 0, end = 0;
    const subs = [...p.subtitles].sort((a, b) => a.start - b.start);
    for (const s of subs) {
      end = s.end;
      const len = end - start;
      if (len >= preset.minLen * 1.6) {
        // pecah kalimat panjang secara merata agar visual tetap bergerak
        const n = Math.max(1, Math.round(len / ((preset.minLen + preset.maxLen) / 2)));
        for (let i = 1; i <= n; i++) cuts.push(+(start + (len * i) / n).toFixed(3));
        start = end;
      }
    }
    if (start < total - 0.2) cuts.push(total);
  } else {
    const beats = p.music?.beats ?? [];
    let t = 0;
    let guard = 0;
    while (t < total - 0.3 && guard++ < 2000) {
      const want = preset.minLen + rand() * (preset.maxLen - preset.minLen);
      let next = t + want;
      if (beats.length) {
        // snap ke beat terdekat dari target; jika tidak ada dalam jangkauan, pakai target
        let best = -1, bd = 1e9;
        for (const b of beats) {
          if (b <= t + preset.minLen * 0.8) continue;
          const d = Math.abs(b - next);
          if (d < bd) { bd = d; best = b; }
        }
        if (best >= 0 && bd < preset.minLen * 0.6) next = best;
      }
      cuts.push(+Math.min(next, total).toFixed(3));
      t = next;
    }
  }
  const uniq = [...new Set(cuts.map((c) => Math.min(c, total)))].sort((a, b) => a - b);
  if (uniq[uniq.length - 1] < total) uniq.push(total);
  // buang segmen yang terlalu pendek (<0.4s) dengan menggabungkan ke sebelumnya
  const out = [uniq[0]];
  for (let i = 1; i < uniq.length; i++) {
    if (uniq[i] - out[out.length - 1] < 0.4 && i < uniq.length - 1) continue;
    out.push(uniq[i]);
  }
  return out;
}

export function targetSeconds(p: Project): number {
  if (p.mode === 'narration' && p.narration) return Math.min(p.maxSeconds + 60, p.narration.durationSec + 0.6);
  if (p.music) return Math.min(p.maxSeconds, p.music.durationSec);
  return Math.min(p.maxSeconds, Math.max(6, p.assets.length * 2.4));
}

function chooseLayout(preset: Preset, rand: () => number, avail: Asset[], idx: number, prev: Layout[], hasText: boolean, cutoutOk: boolean, small: boolean): Layout {
  if (idx === 0) return avail.length && aspect(avail[0]) >= 1 ? 'blurbg' : 'hero';
  const w: Partial<Record<Layout, number>> = {};
  for (const [k, v] of Object.entries(preset.layouts) as [Layout, number][]) {
    if (k === 'typo' && !hasText) continue;
    if (NEED[k] > avail.length) continue;
    if (k === 'cutout' && !cutoutOk) { w[k] = v * 0.4; continue; } // fallback layering, lebih jarang
    w[k] = v;
  }
  if (small) { w.blurbg = (w.blurbg ?? 0) + 4; }
  if (!Object.keys(w).length) return 'hero';
  return pickWeighted(rand, w, [prev[prev.length - 1], prev[prev.length - 2]].filter(Boolean) as Layout[]);
}

export function autoEdit(project: Project, seedOverride?: number): Scene[] {
  const preset = PRESETS[project.preset];
  const seed = seedOverride ?? project.seed;
  const rand = mulberry32(seed);
  const assets = project.assets;
  if (!assets.length) return [];
  const total = targetSeconds(project);
  const cuts = planCuts(project, preset, total, rand);
  const lines = project.textLines.map((t) => t.trim()); // baris kosong = scene tanpa teks
  const scenes: Scene[] = [];
  let cursor = 0;
  let lastCam: CameraMove | undefined;
  let lastTr: TransitionType | undefined;
  const prevLayouts: Layout[] = [];
  const subs = [...project.subtitles].sort((a, b) => a.start - b.start);
  const inten = project.intensity;

  for (let i = 0; i < cuts.length - 1; i++) {
    const startSec = cuts[i], endSec = cuts[i + 1];
    const dur = Math.max(8, Math.round((endSec - startSec) * FPS));
    // aset berurutan (urutan pengguna dihormati), memutar bila habis
    const avail: Asset[] = [];
    for (let k = 0; k < Math.min(3, assets.length); k++) avail.push(assets[(cursor + k) % assets.length]);
    const mid = (startSec + endSec) / 2;
    const sub = subs.find((s) => s.start <= mid && s.end >= mid);
    const lineText = project.mode === 'music' ? lines[i] || undefined : undefined;
    const keyPhrase = sub?.keywords?.length ? sub.keywords.slice(0, 2).join(' ').toUpperCase() : undefined;
    const hasText = !!(lineText || keyPhrase);
    const small = Math.min(avail[0].width, avail[0].height) < 720;
    let layout = chooseLayout(preset, rand, avail, i, prevLayouts, hasText, !!avail[0].cutout, small);
    // gambar landscape di hero: pakai blur-background kecuali kamera pan horizontal
    if (layout === 'hero' && aspect(avail[0]) > 1.2 && rand() < 0.5) layout = 'blurbg';
    prevLayouts.push(layout);
    const used = Math.max(1, NEED[layout]);
    cursor = (cursor + used) % assets.length;

    let camera = pickWeighted(rand, preset.cameras, lastCam ? [lastCam] : []);
    if (layout === 'hero' && aspect(avail[0]) > 1.2 && lastCam !== 'panH' && rand() < 0.6) camera = 'panH';
    if (layout === 'multilayer' && lastCam !== 'parallax') camera = 'parallax';
    lastCam = camera;

    let transition: TransitionType = i === 0 ? 'cut' : pickWeighted(rand, preset.transitions, lastTr ? [lastTr] : []);
    lastTr = transition;
    const [tmin, tmax] = preset.transitionFrames;
    const trFrames = transition === 'cut' ? 0 : Math.min(Math.round(dur * 0.45), Math.round(tmin + rand() * (tmax - tmin)));

    const style = preset.textStyles[Math.floor(rand() * preset.textStyles.length)] as TextStyle;
    const glitch = rand() < preset.glitchChance * (0.4 + inten);
    const flash = i > 0 && rand() < preset.flashChance * (0.4 + inten);
    let sfx: SfxName = 'none';
    if (i > 0) {
      sfx = transition === 'whip' || transition === 'slide' ? 'whoosh'
        : transition === 'glitch' || glitch ? 'glitch'
        : transition === 'flash' || flash ? 'impact'
        : transition === 'zoom' ? 'whoosh'
        : i % 4 === 0 ? 'bass' : transition === 'cut' ? 'pop' : 'none';
    }
    scenes.push({
      id: `sc${i}_${seed}`, assetIds: avail.slice(0, used).map((a) => a.id), layout, camera, transition,
      transitionFrames: trFrames, durationFrames: dur,
      text: lineText ?? (layout === 'typo' ? keyPhrase : undefined),
      keywords: sub?.keywords, textStyle: style, sfx,
      seed: Math.floor(rand() * 1e6), intensity: Math.min(1, inten * (0.7 + rand() * 0.6)), glitch, flash,
    });
  }
  // Pastikan layout 'typo' tanpa teks tidak lolos
  for (const s of scenes) if (s.layout === 'typo' && !s.text) s.layout = 'poster';
  return scenes;
}
