export function mulberry32(seed: number) {
  let a = seed >>> 0;
  return () => {
    a = (a + 0x6d2b79f5) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}
export function pickWeighted<T extends string>(rand: () => number, weights: Partial<Record<T, number>>, exclude: T[] = []): T {
  const entries = (Object.entries(weights) as [T, number][]).filter(([k, w]) => w > 0 && !exclude.includes(k));
  const list = entries.length ? entries : (Object.entries(weights) as [T, number][]).filter(([, w]) => w > 0);
  const total = list.reduce((s, [, w]) => s + w, 0);
  let r = rand() * total;
  for (const [k, w] of list) { r -= w; if (r <= 0) return k; }
  return list[list.length - 1][0];
}
