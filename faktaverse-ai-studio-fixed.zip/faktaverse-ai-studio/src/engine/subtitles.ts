import type { Subtitle } from './types';

const STOP = new Set(['yang','dan','di','ke','dari','untuk','dengan','ini','itu','pada','adalah','atau','akan','juga','saat','kita','kamu','saya','the','a','an','of','to','in','is','and','that','it','for','on','was','as','with','at','by','are','be','this','from','or']);

/** Heuristik lokal (tanpa AI): angka, kata kapital di tengah kalimat, dan kata terpanjang. */
export function heuristicKeywords(text: string, max = 3): string[] {
  const words = text.replace(/[^\p{L}\p{N}\s'-]/gu, '').split(/\s+/).filter(Boolean);
  const scored = words.map((w, i) => {
    let s = 0;
    if (/\d/.test(w)) s += 4;
    if (i > 0 && /^\p{Lu}/u.test(w)) s += 3;
    if (!STOP.has(w.toLowerCase())) s += Math.min(w.length, 10) / 4;
    return { w, s };
  });
  return [...new Set(scored.sort((a, b) => b.s - a.s).slice(0, max).filter((x) => x.s > 1.5).map((x) => x.w))];
}

export function splitSentences(script: string): string[] {
  return script
    .replace(/\r/g, '')
    .split(/(?<=[.!?…])\s+|\n+/u)
    .map((s) => s.trim())
    .filter(Boolean);
}

/** Distribusi kalimat naskah ke durasi narasi, sebanding jumlah karakter. Timing ditandai 'estimated'. */
export function estimateFromScript(script: string, durationSec: number): Subtitle[] {
  const sentences = splitSentences(script);
  const total = sentences.reduce((s, t) => s + t.length + 8, 0) || 1;
  let t = 0;
  return sentences.map((text, i) => {
    const len = ((text.length + 8) / total) * durationSec;
    const sub: Subtitle = { id: `s${i}`, start: t, end: t + len, text, keywords: heuristicKeywords(text), timing: 'estimated' };
    t += len;
    return sub;
  });
}

function tc(s: string): number {
  const m = s.trim().match(/(\d+):(\d+):(\d+)[,.](\d+)/);
  if (!m) return NaN;
  return +m[1] * 3600 + +m[2] * 60 + +m[3] + +m[4].padEnd(3, '0').slice(0, 3) / 1000;
}

/** Parser SRT: timing kalimat nyata dari file pengguna. */
export function parseSrt(srt: string): Subtitle[] {
  const out: Subtitle[] = [];
  for (const block of srt.replace(/\r/g, '').split(/\n{2,}/)) {
    const lines = block.split('\n').filter(Boolean);
    const ti = lines.findIndex((l) => l.includes('-->'));
    if (ti < 0) continue;
    const [a, b] = lines[ti].split('-->');
    const start = tc(a), end = tc(b);
    const text = lines.slice(ti + 1).join(' ').replace(/<[^>]+>/g, '').trim();
    if (!text || isNaN(start) || isNaN(end) || end <= start) continue;
    out.push({ id: `s${out.length}`, start, end, text, keywords: heuristicKeywords(text), timing: 'sentence' });
  }
  return out;
}
