export const FPS = 30;
export const WIDTH = 1080;
export const HEIGHT = 1920;

export type PresetId = 'brainrot' | 'meme' | 'cinematic' | 'history' | 'mystery' | 'hybrid';
export type Layout =
  | 'hero' | 'double' | 'triple' | 'floating' | 'tilted' | 'cutout'
  | 'pip' | 'multilayer' | 'blurbg' | 'typo' | 'poster';
export type CameraMove =
  | 'zoomIn' | 'zoomOut' | 'punch' | 'shake' | 'panH' | 'panV' | 'rotate' | 'parallax' | 'whip' | 'still';
export type TransitionType = 'cut' | 'flash' | 'whip' | 'zoom' | 'glitch' | 'fade' | 'slide' | 'spin';
export type TextStyle =
  | 'pop' | 'bounce' | 'shake' | 'rotate' | 'sticker' | 'chars' | 'words' | 'outline' | 'block' | 'label';
export type SfxName = 'whoosh' | 'impact' | 'bass' | 'pop' | 'glitch' | 'none';

export interface Asset {
  id: string;
  name: string;
  kind: 'image' | 'video';
  /** path relatif terhadap folder proyek, mis. "assets/abc.jpg" */
  file: string;
  width: number;
  height: number;
  durationSec?: number;
  /** PNG tanpa background (hanya jika layanan background-removal terkonfigurasi) */
  cutout?: string;
}

export interface AudioAsset {
  name: string;
  file: string;
  durationSec: number;
  bpm?: number;
  /** detik */
  beats?: number[];
  normalized?: boolean;
}

export interface Subtitle {
  id: string;
  start: number; // detik
  end: number;
  text: string;
  keywords: string[];
  /** word = timestamp kata nyata dari transkripsi; sentence = timing kalimat nyata (SRT/transkripsi); estimated = diperkirakan dari naskah */
  timing: 'word' | 'sentence' | 'estimated';
  words?: { w: string; start: number; end: number }[];
}

export interface Scene {
  id: string;
  assetIds: string[];
  layout: Layout;
  camera: CameraMove;
  transition: TransitionType;
  transitionFrames: number;
  durationFrames: number;
  text?: string;
  keywords?: string[];
  textStyle: TextStyle;
  sfx: SfxName;
  seed: number;
  /** 0..1 intensitas efek khusus scene */
  intensity: number;
  glitch: boolean;
  flash: boolean;
}

export interface AudioConfig {
  musicVolume: number;
  narrationVolume: number;
  sfxVolume: number;
  duckTo: number; // pengali volume musik saat ada narasi (0..1)
  fadeInSec: number;
  fadeOutSec: number;
  sfxEnabled: boolean;
}

export interface TypographyConfig {
  font: 'anton' | 'montserrat' | 'system';
  sizeScale: number;
  captionPosition: 'top' | 'center' | 'bottom';
  captionStyle: TextStyle;
  showTitleBar: boolean;
}

export interface Project {
  id: string;
  name: string;
  title: string; // judul bar atas (opsional, dari pengguna)
  createdAt: string;
  updatedAt: string;
  preset: PresetId;
  mode: 'music' | 'narration';
  assets: Asset[];
  music?: AudioAsset;
  narration?: AudioAsset;
  /** Teks buatan pengguna: satu baris per scene (mode musik). Tidak pernah dikarang AI. */
  textLines: string[];
  /** naskah narasi yang ditempel pengguna (mode manual) */
  narrationScript: string;
  subtitles: Subtitle[];
  scenes: Scene[];
  audio: AudioConfig;
  typography: TypographyConfig;
  intensity: number; // 0..1 intensitas efek global
  maxSeconds: number;
  seed: number;
  fps: number;
  render: { concurrency: number; output: string };
}

export const defaultAudio: AudioConfig = {
  musicVolume: 0.8, narrationVolume: 1, sfxVolume: 0.7, duckTo: 0.25,
  fadeInSec: 0.6, fadeOutSec: 1.2, sfxEnabled: true,
};
export const defaultTypography: TypographyConfig = {
  font: 'anton', sizeScale: 1, captionPosition: 'bottom', captionStyle: 'pop', showTitleBar: true,
};

export function newProject(id: string, name: string): Project {
  const now = new Date().toISOString();
  return {
    id, name, title: '', createdAt: now, updatedAt: now, preset: 'hybrid', mode: 'music',
    assets: [], textLines: [], narrationScript: '', subtitles: [], scenes: [],
    audio: { ...defaultAudio }, typography: { ...defaultTypography },
    intensity: 0.7, maxSeconds: 45, seed: 1234, fps: FPS,
    render: { concurrency: 2, output: 'out/faktaverse-final.mp4' },
  };
}

export function totalFrames(p: Pick<Project, 'scenes'>): number {
  return Math.max(30, p.scenes.reduce((s, sc) => s + sc.durationFrames, 0));
}
