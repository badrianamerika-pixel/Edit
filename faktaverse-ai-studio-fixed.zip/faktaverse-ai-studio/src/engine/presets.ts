import type { CameraMove, Layout, PresetId, TextStyle, TransitionType } from './types';

export interface Preset {
  id: PresetId;
  label: string;
  description: string;
  minLen: number; // detik per scene
  maxLen: number;
  layouts: Partial<Record<Layout, number>>;
  cameras: Partial<Record<CameraMove, number>>;
  transitions: Partial<Record<TransitionType, number>>;
  transitionFrames: [number, number];
  textStyles: TextStyle[];
  accent: string;
  accent2: string;
  bg: string;
  grade: string; // CSS filter
  grain: number; // 0..1
  vignette: number; // 0..1
  shake: number; // 0..1 basis kamera
  glitchChance: number;
  flashChance: number;
  font: 'anton' | 'montserrat';
}

export const PRESETS: Record<PresetId, Preset> = {
  brainrot: {
    id: 'brainrot', label: 'Brainrot', description: 'Cut cepat, teks raksasa, shake, flash, warna mencolok.',
    minLen: 0.7, maxLen: 1.6,
    layouts: { hero: 3, typo: 2, double: 2, floating: 2, tilted: 2, cutout: 2, poster: 2, pip: 1 },
    cameras: { punch: 4, shake: 4, zoomIn: 3, whip: 2, rotate: 2 },
    transitions: { cut: 3, flash: 3, whip: 3, glitch: 2, zoom: 2 },
    transitionFrames: [3, 6], textStyles: ['pop', 'shake', 'bounce', 'sticker', 'label'],
    accent: '#ff2d55', accent2: '#ffe600', bg: '#0a0a12',
    grade: 'contrast(1.2) saturate(1.45)', grain: 0.12, vignette: 0.25, shake: 0.9, glitchChance: 0.35, flashChance: 0.4, font: 'anton',
  },
  meme: {
    id: 'meme', label: 'Meme', description: 'Kolase, kartu miring, stiker, punch zoom, glitch.',
    minLen: 1.0, maxLen: 2.2,
    layouts: { floating: 4, tilted: 4, triple: 3, cutout: 3, double: 2, poster: 2, pip: 2, hero: 1 },
    cameras: { punch: 4, zoomIn: 2, rotate: 2, shake: 2, panH: 1 },
    transitions: { cut: 3, flash: 2, glitch: 3, slide: 2, spin: 1 },
    transitionFrames: [4, 8], textStyles: ['sticker', 'label', 'pop', 'bounce', 'rotate'],
    accent: '#ff3b30', accent2: '#ffd60a', bg: '#101018',
    grade: 'contrast(1.1) saturate(1.3)', grain: 0.06, vignette: 0.15, shake: 0.5, glitchChance: 0.25, flashChance: 0.2, font: 'anton',
  },
  cinematic: {
    id: 'cinematic', label: 'Cinematic Documentary', description: 'Zoom halus, grain film, pencahayaan dramatis.',
    minLen: 2.4, maxLen: 4.5,
    layouts: { hero: 5, blurbg: 3, double: 1, multilayer: 2, pip: 1 },
    cameras: { zoomIn: 4, zoomOut: 3, panH: 3, panV: 2, parallax: 2 },
    transitions: { fade: 5, slide: 1, zoom: 1, cut: 1 },
    transitionFrames: [14, 22], textStyles: ['words', 'chars', 'outline'],
    accent: '#f2c879', accent2: '#ffffff', bg: '#050507',
    grade: 'contrast(1.15) saturate(0.85) sepia(0.12) brightness(0.95)', grain: 0.32, vignette: 0.55, shake: 0, glitchChance: 0, flashChance: 0, font: 'montserrat',
  },
  history: {
    id: 'history', label: 'Fast-Paced History', description: 'Kolase sejarah, judul tebal, transisi cepat, dramatis.',
    minLen: 1.4, maxLen: 3.0,
    layouts: { triple: 3, multilayer: 3, hero: 3, double: 2, tilted: 2, poster: 3, blurbg: 2 },
    cameras: { panH: 3, zoomIn: 3, parallax: 3, punch: 2, panV: 1 },
    transitions: { whip: 3, slide: 3, cut: 2, fade: 1, flash: 1 },
    transitionFrames: [6, 12], textStyles: ['block', 'label', 'words', 'pop'],
    accent: '#c1272d', accent2: '#e8d9a8', bg: '#14100a',
    grade: 'contrast(1.18) saturate(0.7) sepia(0.35)', grain: 0.22, vignette: 0.45, shake: 0.2, glitchChance: 0.05, flashChance: 0.1, font: 'anton',
  },
  mystery: {
    id: 'mystery', label: 'Mystery Storytelling', description: 'Gelap, zoom dramatis, glitch tipis, kata kunci menyala.',
    minLen: 2.0, maxLen: 4.0,
    layouts: { hero: 4, blurbg: 3, multilayer: 2, pip: 2, typo: 1 },
    cameras: { zoomIn: 5, zoomOut: 2, panV: 2, shake: 1, punch: 1 },
    transitions: { fade: 3, glitch: 3, cut: 2, zoom: 1 },
    transitionFrames: [8, 16], textStyles: ['words', 'outline', 'chars', 'shake'],
    accent: '#27e1c1', accent2: '#ff2d55', bg: '#030508',
    grade: 'contrast(1.25) saturate(0.7) brightness(0.8) hue-rotate(-8deg)', grain: 0.28, vignette: 0.7, shake: 0.25, glitchChance: 0.3, flashChance: 0.05, font: 'montserrat',
  },
  hybrid: {
    id: 'hybrid', label: 'Hybrid', description: 'Gabungan Brainrot + Meme + Cinematic. Pilihan aman.',
    minLen: 1.1, maxLen: 2.8,
    layouts: { hero: 3, floating: 3, tilted: 3, double: 2, triple: 2, cutout: 2, blurbg: 2, multilayer: 2, pip: 1, poster: 2, typo: 1 },
    cameras: { zoomIn: 3, zoomOut: 2, punch: 3, panH: 2, panV: 1, shake: 1, parallax: 2, rotate: 1, whip: 1 },
    transitions: { cut: 2, flash: 2, whip: 2, glitch: 1, fade: 2, slide: 2, zoom: 1 },
    transitionFrames: [5, 12], textStyles: ['pop', 'sticker', 'label', 'words', 'bounce', 'outline'],
    accent: '#ff2d55', accent2: '#ffd60a', bg: '#0b0d14',
    grade: 'contrast(1.14) saturate(1.1)', grain: 0.14, vignette: 0.35, shake: 0.4, glitchChance: 0.15, flashChance: 0.15, font: 'anton',
  },
};
