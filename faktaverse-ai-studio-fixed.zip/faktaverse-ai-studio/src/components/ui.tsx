import React from 'react';

export const Section: React.FC<{ title: string; hint?: string; children: React.ReactNode; right?: React.ReactNode }> = ({ title, hint, children, right }) => (
  <section className="glass p-4 mb-4">
    <div className="flex items-start justify-between gap-3 mb-3">
      <div><h2 className="font-extrabold text-lg">{title}</h2>{hint && <p className="text-sm text-white/55 mt-0.5">{hint}</p>}</div>
      {right}
    </div>
    {children}
  </section>
);

export const Range: React.FC<{ label: string; value: number; min: number; max: number; step: number; onChange: (v: number) => void; fmt?: (v: number) => string }> = ({ label, value, min, max, step, onChange, fmt }) => (
  <label className="block mb-2">
    <div className="flex justify-between text-sm text-white/70"><span>{label}</span><span className="font-mono">{fmt ? fmt(value) : value}</span></div>
    <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} />
  </label>
);

export const Select = <T extends string>({ label, value, options, onChange }: { label: string; value: T; options: { v: T; l: string }[]; onChange: (v: T) => void }) => (
  <label className="block mb-2">
    <div className="text-sm text-white/70 mb-1">{label}</div>
    <select className="field" value={value} onChange={(e) => onChange(e.target.value as T)}>
      {options.map((o) => <option key={o.v} value={o.v}>{o.l}</option>)}
    </select>
  </label>
);

export const Toggle: React.FC<{ label: string; value: boolean; onChange: (v: boolean) => void }> = ({ label, value, onChange }) => (
  <button type="button" className="flex w-full items-center justify-between min-h-[48px] text-left" onClick={() => onChange(!value)}>
    <span className="text-sm text-white/80">{label}</span>
    <span className={`w-12 h-7 rounded-full p-1 transition ${value ? 'bg-fv-acc' : 'bg-white/20'}`}><span className={`block w-5 h-5 rounded-full bg-white transition ${value ? 'translate-x-5' : ''}`} /></span>
  </button>
);

export const Notice: React.FC<{ kind?: 'info' | 'warn' | 'err'; children: React.ReactNode }> = ({ kind = 'info', children }) => (
  <div className={`rounded-xl p-3 text-sm mb-3 ${kind === 'err' ? 'bg-red-500/15 text-red-200' : kind === 'warn' ? 'bg-yellow-500/15 text-yellow-100' : 'bg-white/8 text-white/70'}`}>{children}</div>
);
