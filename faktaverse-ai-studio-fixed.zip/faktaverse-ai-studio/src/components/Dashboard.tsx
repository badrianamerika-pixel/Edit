import React, { useEffect, useState } from 'react';
import { Film, Plus, Trash2, Upload } from 'lucide-react';
import { api, type Caps, type ProjectSummary } from '../services/api';
import { useProject } from '../state/useProject';
import { PRESETS } from '../engine/presets';
import type { PresetId } from '../engine/types';
import { Notice } from './ui';

export const Dashboard: React.FC = () => {
  const { open } = useProject();
  const [list, setList] = useState<ProjectSummary[] | null>(null);
  const [caps, setCaps] = useState<Caps | null>(null);
  const [name, setName] = useState('');
  const [err, setErr] = useState('');
  const refresh = () => api.list().then(setList).catch((e) => setErr(`Tidak bisa terhubung ke server API: ${e.message}. Jalankan "npm run preview" dan pastikan port 3001 aktif.`));
  useEffect(() => { refresh(); api.caps().then(setCaps).catch(() => {}); }, []);

  const create = async () => { try { const p = await api.create(name || 'Proyek Baru'); await open(p.id); } catch (e) { setErr((e as Error).message); } };
  const importFile = async (f: File) => {
    try { const r = await api.importProject(JSON.parse(await f.text())); await open(r.project.id); if (r.missing.length) alert(`Konfigurasi diimpor, tetapi aset berikut belum ada: ${r.missing.join(', ')}. Unggah ulang di tab Media.`); }
    catch (e) { setErr((e as Error).message); }
  };

  return (
    <div className="max-w-3xl mx-auto px-4 safe-t pt-6 pb-10">
      <h1 className="text-3xl font-black tracking-tight">FAKTAVERSE <span className="text-fv-acc">AI STUDIO</span></h1>
      <p className="text-white/60 mt-1 mb-5">Upload media → Edit otomatis → Preview → Simpan → Render manual di Codespaces.</p>
      {err && <Notice kind="err">{err}</Notice>}
      {caps && (
        <div className="flex flex-wrap gap-2 mb-4 text-xs">
          {[['FFmpeg', caps.ffmpeg], ['Transkripsi (OpenAI)', caps.transcribe], ['Kata kunci AI (Anthropic)', caps.keywords], ['Hapus background', caps.cutout]].map(([l, ok]) => (
            <span key={String(l)} className={`px-2.5 py-1 rounded-full ${ok ? 'bg-emerald-500/20 text-emerald-300' : 'bg-white/10 text-white/50'}`}>{ok ? '●' : '○'} {l as string}{!ok && l !== 'FFmpeg' ? ' (mode fallback)' : ''}</span>
          ))}
        </div>
      )}
      <div className="glass p-4 mb-5 flex gap-2">
        <input className="field" placeholder="Nama proyek baru" value={name} onChange={(e) => setName(e.target.value)} />
        <button className="btn btn-pri shrink-0" onClick={create}><Plus size={20} />Buat</button>
      </div>
      <h2 className="font-extrabold mb-2">Proyek</h2>
      {list === null && !err && <p className="text-white/50">Memuat…</p>}
      {list?.length === 0 && <Notice>Belum ada proyek. Buat satu di atas, atau jalankan <code>npm run setup</code> untuk membuat proyek demo.</Notice>}
      <div className="grid gap-3">
        {list?.map((p) => (
          <div key={p.id} className="glass p-3 flex items-center gap-3">
            <button className="flex flex-1 items-center gap-3 text-left min-w-0" onClick={() => open(p.id)}>
              <div className="w-14 h-20 rounded-lg bg-black/40 overflow-hidden shrink-0 flex items-center justify-center">{p.thumb ? <img src={p.thumb} className="w-full h-full object-cover" /> : <Film className="text-white/30" />}</div>
              <div className="min-w-0">
                <div className="font-bold truncate">{p.name}</div>
                <div className="text-xs text-white/55">{PRESETS[p.preset as PresetId]?.label ?? p.preset} • {p.assets} aset • {p.scenes} scene • {p.seconds}s</div>
                <div className="text-[11px] text-white/35">{new Date(p.updatedAt).toLocaleString('id-ID')}</div>
              </div>
            </button>
            <button className="btn btn-sm" onClick={async () => { if (confirm(`Hapus proyek "${p.name}" beserta aset?`)) { await api.remove(p.id); refresh(); } }}><Trash2 size={16} /></button>
          </div>
        ))}
      </div>
      <label className="btn mt-5 w-full cursor-pointer"><Upload size={18} />Impor konfigurasi proyek (.json)
        <input type="file" accept="application/json,.json" hidden onChange={(e) => e.target.files?.[0] && importFile(e.target.files[0])} />
      </label>
    </div>
  );
};
