import React, { useEffect, useRef, useState } from 'react';
import { ArrowDown, ArrowUp, Music, Mic, Replace, Scissors, Trash2, Upload } from 'lucide-react';
import { api } from '../services/api';
import { useProject } from '../state/useProject';
import { Notice, Section } from './ui';

export const MediaPanel: React.FC<{ goStyle: () => void }> = ({ goStyle }) => {
  const { project, update, replace, pause, saveNow } = useProject();
  const [progress, setProgress] = useState<{ label: string; pct: number } | null>(null);
  const [errors, setErrors] = useState<string[]>([]);
  const [caps, setCaps] = useState<null | { transcribe: boolean; cutout: boolean }>(null);
  useEffect(() => { api.caps().then(setCaps).catch(() => {}); }, []);
  const [script, setScript] = useState(project?.narrationScript ?? '');
  const [srt, setSrt] = useState('');
  const [busy, setBusy] = useState('');
  const replaceFor = useRef<string | null>(null);
  const replaceInput = useRef<HTMLInputElement>(null);
  if (!project) return null;

  const doUpload = async (kind: 'media' | 'music' | 'narration', files: File[], label: string) => {
    if (!files.length) return [];
    setErrors([]); pause(true);
    try {
      await saveNow().catch(() => {});
      const r = await api.upload(project.id, kind, files, (pct) => setProgress({ label, pct }));
      replace(r.project); setErrors(r.errors); return r.project.assets;
    } catch (e) { setErrors([(e as Error).message]); return []; }
    finally { pause(false); setProgress(null); }
  };

  const doReplace = async (file: File) => {
    const oldId = replaceFor.current; if (!oldId) return;
    const before = new Set(project.assets.map((a) => a.id));
    const after = await doUpload('media', [file], 'Mengganti gambar');
    const added = after.find((a) => !before.has(a.id));
    if (!added) return;
    update((p) => ({ ...p, assets: p.assets.filter((a) => a.id !== oldId), scenes: p.scenes.map((s) => ({ ...s, assetIds: s.assetIds.map((i) => (i === oldId ? added.id : i)) })) }));
    api.deleteAsset(project.id, oldId).catch(() => {});
  };

  const move = (i: number, d: number) => update((p) => { const a = [...p.assets]; const j = i + d; if (j < 0 || j >= a.length) return p; [a[i], a[j]] = [a[j], a[i]]; return { ...p, assets: a }; });
  const run = async (label: string, fn: () => Promise<unknown>) => { setBusy(label); setErrors([]); try { await fn(); } catch (e) { setErrors([(e as Error).message]); } finally { setBusy(''); } };
  const base = `/files/${project.id}/`;

  return (
    <div className="pt-2">
      {progress && <div className="fixed left-4 right-4 top-16 z-20 glass p-3"><div className="text-sm mb-1">{progress.label}… {progress.pct}%{progress.pct === 100 ? ' (memproses di server)' : ''}</div><div className="h-2 rounded bg-white/15"><div className="h-2 rounded bg-fv-acc" style={{ width: `${progress.pct}%` }} /></div></div>}
      {errors.length > 0 && <Notice kind="err">{errors.map((e, i) => <div key={i}>{e}</div>)}</Notice>}

      <Section title="Gambar & Video" hint="Urutan di sini dipakai mesin edit otomatis. Gambar besar otomatis diperkecil (maks 2160px).">
        <label className="btn btn-pri w-full cursor-pointer"><Upload size={20} />Pilih gambar / klip video
          <input type="file" multiple accept="image/*,video/mp4,video/quicktime,video/webm" hidden onChange={(e) => { const f = Array.from(e.target.files ?? []); e.target.value = ''; doUpload('media', f, 'Mengunggah media'); }} />
        </label>
        <input ref={replaceInput} type="file" accept="image/*,video/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) doReplace(f); }} />
        <div className="grid grid-cols-2 gap-3 mt-4">
          {project.assets.map((a, i) => (
            <div key={a.id} className="glass overflow-hidden">
              <div className="aspect-[3/4] bg-black/50 relative">
                {a.kind === 'image' ? <img src={base + a.file} className="w-full h-full object-cover" loading="lazy" /> : <video src={base + a.file} className="w-full h-full object-cover" muted playsInline />}
                <span className="absolute top-1 left-1 text-[11px] bg-black/70 rounded px-1.5">{i + 1}{a.kind === 'video' ? ' ▶' : ''}{a.cutout ? ' ✂' : ''}</span>
              </div>
              <div className="p-2">
                <div className="text-[11px] text-white/55 truncate">{a.name} • {a.width}×{a.height}</div>
                <div className="flex gap-1 mt-1.5 flex-wrap">
                  <button className="btn btn-sm !px-2" onClick={() => move(i, -1)}><ArrowUp size={15} /></button>
                  <button className="btn btn-sm !px-2" onClick={() => move(i, 1)}><ArrowDown size={15} /></button>
                  <button className="btn btn-sm !px-2" onClick={() => { replaceFor.current = a.id; replaceInput.current?.click(); }}><Replace size={15} /></button>
                  {a.kind === 'image' && <button className="btn btn-sm !px-2" disabled={!caps?.cutout || !!busy} title={caps?.cutout ? 'Hapus background' : 'REMOVEBG_API_KEY belum diatur: fallback layering'} onClick={() => run('cutout', async () => replace(await api.cutout(project.id, a.id)))}><Scissors size={15} /></button>}
                  <button className="btn btn-sm !px-2" onClick={async () => { if (confirm('Hapus aset ini?')) replace(await api.deleteAsset(project.id, a.id)); }}><Trash2 size={15} /></button>
                </div>
              </div>
            </div>
          ))}
        </div>
        {!project.assets.length && <p className="text-sm text-white/50 mt-3">Belum ada media.</p>}
        {caps && !caps.cutout && project.assets.length > 0 && <p className="text-xs text-white/40 mt-3">✂ Portrait cutout membutuhkan REMOVEBG_API_KEY. Tanpa itu, layout "cutout" memakai kartu foto biasa (tidak berpura-pura memotong background).</p>}
      </Section>

      <Section title="Musik latar" hint="Dinormalisasi otomatis; beat dideteksi untuk sinkronisasi potongan.">
        <label className="btn w-full cursor-pointer"><Music size={20} />{project.music ? 'Ganti musik' : 'Pilih musik'}
          <input type="file" accept="audio/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) doUpload('music', [f], 'Mengunggah musik'); }} />
        </label>
        {project.music && (
          <div className="mt-3 text-sm">
            <audio controls src={base + project.music.file} className="w-full" />
            <div className="text-white/60 mt-2">{project.music.name} • {project.music.durationSec}s • {project.music.beats?.length ?? 0} beat{project.music.bpm ? ` • ~${project.music.bpm} BPM` : ''} {project.music.normalized ? '• ternormalisasi' : '• (tanpa normalisasi)'}</div>
            {!project.music.beats?.length && <Notice kind="warn">Beat tidak terdeteksi — potongan memakai grid tempo biasa.</Notice>}
            <button className="btn btn-sm mt-2" onClick={async () => replace(await api.deleteAudio(project.id, 'music'))}><Trash2 size={15} />Hapus</button>
          </div>
        )}
      </Section>

      <Section title="Narasi (opsional)" hint="Tanpa narasi: montase berbasis musik. Tidak ada narasi/subtitle yang dikarang otomatis.">
        <label className="btn w-full cursor-pointer"><Mic size={20} />{project.narration ? 'Ganti narasi' : 'Pilih rekaman narasi'}
          <input type="file" accept="audio/*" hidden onChange={(e) => { const f = e.target.files?.[0]; e.target.value = ''; if (f) doUpload('narration', [f], 'Mengunggah narasi'); }} />
        </label>
        {project.narration && (
          <div className="mt-3 text-sm">
            <audio controls src={base + project.narration.file} className="w-full" />
            <div className="text-white/60 my-2">{project.narration.name} • {project.narration.durationSec}s</div>
            <button className="btn w-full mb-2" disabled={!caps?.transcribe || !!busy} onClick={() => run('t', async () => replace(await api.transcribe(project.id)))}>{busy === 't' ? 'Mentranskripsi…' : caps?.transcribe ? 'Transkripsi otomatis (timestamp kata)' : 'Transkripsi otomatis (butuh OPENAI_API_KEY)'}</button>
            <div className="text-white/70 mb-1">Mode manual — tempel naskah (timing hanya perkiraan):</div>
            <textarea className="field" value={script} onChange={(e) => setScript(e.target.value)} placeholder="Tempel naskah narasi. Satu kalimat per baris atau dipisah titik." />
            <button className="btn btn-sm mt-2" disabled={!script.trim() || !!busy} onClick={() => run('s', async () => replace(await api.subtitles(project.id, { script })))}>Buat subtitle dari naskah</button>
            <div className="text-white/70 mt-3 mb-1">atau tempel SRT (timing kalimat nyata):</div>
            <textarea className="field" value={srt} onChange={(e) => setSrt(e.target.value)} placeholder={'1\n00:00:00,000 --> 00:00:03,200\nKalimat pertama'} />
            <button className="btn btn-sm mt-2" disabled={!srt.trim() || !!busy} onClick={() => run('r', async () => replace(await api.subtitles(project.id, { srt })))}>Impor SRT</button>
            {project.subtitles.length > 0 && <Notice>{project.subtitles.length} subtitle • timing: {project.subtitles[0].timing === 'word' ? 'kata (nyata)' : project.subtitles[0].timing === 'sentence' ? 'kalimat (nyata)' : 'perkiraan dari naskah'}</Notice>}
            <button className="btn btn-sm mt-1" onClick={async () => replace(await api.deleteAudio(project.id, 'narration'))}><Trash2 size={15} />Hapus narasi</button>
          </div>
        )}
      </Section>

      <button className="btn btn-pri w-full" disabled={!project.assets.length} onClick={goStyle}>Lanjut: pilih gaya →</button>
    </div>
  );
};
