import React from 'react';
import { Shuffle, Sparkles } from 'lucide-react';
import { autoEdit, targetSeconds } from '../engine/autoEdit';
import { PRESETS } from '../engine/presets';
import { totalFrames, type PresetId } from '../engine/types';
import { useProject } from '../state/useProject';
import { Notice, Range, Section } from './ui';

export const StylePanel: React.FC<{ onDone: () => void }> = ({ onDone }) => {
  const { project, update } = useProject();
  if (!project) return null;
  const hasNarration = !!project.narration;
  const noSubs = hasNarration && project.subtitles.length === 0;

  const run = (reseed: boolean) => {
    const seed = reseed ? Math.floor(Math.random() * 1e6) : project.seed;
    update((p) => ({ ...p, seed, scenes: autoEdit({ ...p, seed }, seed) }));
    onDone();
  };

  return (
    <div className="pt-2">
      <Section title="Gaya editing" hint="Setiap preset punya komposisi, kamera, transisi, tipografi, dan color grade sendiri.">
        <div className="grid gap-2">
          {(Object.values(PRESETS)).map((pr) => (
            <button key={pr.id} onClick={() => update((p) => ({ ...p, preset: pr.id as PresetId }))} className={`text-left p-3 rounded-2xl border transition ${project.preset === pr.id ? 'border-fv-acc bg-fv-acc/15' : 'border-white/10 bg-white/5'}`}>
              <div className="flex items-center gap-2"><span className="w-3 h-3 rounded-full" style={{ background: pr.accent }} /><span className="w-3 h-3 rounded-full" style={{ background: pr.accent2 }} /><b>{pr.label}</b></div>
              <div className="text-sm text-white/60 mt-1">{pr.description}</div>
            </button>
          ))}
        </div>
      </Section>

      <Section title="Teks (opsional)" hint="Hanya teks yang kamu tulis yang akan tampil. Mesin tidak mengarang teks atau narasi.">
        <label className="block text-sm text-white/70 mb-1">Judul bar atas (seperti referensi)</label>
        <input className="field mb-3" placeholder="mis. WAHH INI GILA 🔥" value={project.title} onChange={(e) => update((p) => ({ ...p, title: e.target.value }))} />
        {!hasNarration && (
          <>
            <label className="block text-sm text-white/70 mb-1">Teks per scene (satu baris = satu scene; baris kosong = tanpa teks)</label>
            <textarea className="field" value={project.textLines.join('\n')} onChange={(e) => update((p) => ({ ...p, textLines: e.target.value.split('\n') }))} placeholder={'TAHUKAH KAMU?\n\nFAKTA #1'} />
          </>
        )}
        {hasNarration && <Notice>Mode narasi: subtitle dibuat dari narasi (tab Media). Teks besar hanya memakai kata kunci dari narasi itu.</Notice>}
      </Section>

      <Section title="Pengaturan umum">
        <Range label="Intensitas efek" value={project.intensity} min={0.1} max={1} step={0.05} onChange={(v) => update((p) => ({ ...p, intensity: v }))} fmt={(v) => `${Math.round(v * 100)}%`} />
        {!hasNarration && <Range label="Durasi maksimum video" value={project.maxSeconds} min={10} max={180} step={5} onChange={(v) => update((p) => ({ ...p, maxSeconds: v }))} fmt={(v) => `${v}s`} />}
        <div className="text-sm text-white/55">Perkiraan durasi: {targetSeconds(project).toFixed(1)}s{project.music?.beats?.length ? ' • potongan disinkronkan ke beat' : ' • tanpa data beat'}</div>
      </Section>

      {noSubs && <Notice kind="warn">Narasi sudah diunggah tapi subtitle belum ada. Buat di tab Media (transkripsi / naskah / SRT). Jika dilewati, scene dibagi berdasarkan musik/tempo dan tanpa subtitle.</Notice>}
      {!project.assets.length && <Notice kind="err">Unggah minimal satu gambar di tab Media.</Notice>}

      <button className="btn btn-pri w-full text-lg min-h-[60px]" disabled={!project.assets.length} onClick={() => run(false)}><Sparkles size={22} />AUTOMATIC EDIT</button>
      {project.scenes.length > 0 && (
        <button className="btn w-full mt-3" onClick={() => run(true)}><Shuffle size={18} />Regenerate (variasi baru) • sekarang {project.scenes.length} scene / {(totalFrames(project) / 30).toFixed(1)}s</button>
      )}
    </div>
  );
};
