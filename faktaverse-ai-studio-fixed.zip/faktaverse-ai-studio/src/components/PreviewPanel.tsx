import React, { useMemo, useRef } from 'react';
import { Player, type PlayerRef } from '@remotion/player';
import { Main, type MainProps } from '../remotion/Main';
import { HEIGHT, totalFrames, WIDTH } from '../engine/types';
import { useProject } from '../state/useProject';
import { Notice } from './ui';

export const PreviewPanel: React.FC<{ focusScene: string | null; clearFocus: () => void }> = ({ focusScene, clearFocus }) => {
  const { project } = useProject();
  const ref = useRef<PlayerRef>(null);
  const range = useMemo(() => {
    if (!project || !focusScene) return null;
    let start = 0;
    for (const s of project.scenes) {
      if (s.id === focusScene) return { in: start, out: start + s.durationFrames - 1 };
      start += s.durationFrames;
    }
    return null;
  }, [project, focusScene]);
  if (!project) return null;
  if (!project.scenes.length) return <Notice>Belum ada komposisi. Tekan AUTOMATIC EDIT di tab Gaya.</Notice>;
  const frames = totalFrames(project);
  const props: MainProps = { project, base: `/files/${project.id}/` };

  return (
    <div className="pt-2">
      <p className="text-sm text-white/55 mb-2">Preview memakai komposisi Remotion yang sama dengan render final. Ketuk video untuk memutar (audio aktif setelah interaksi).</p>
      <div className="mx-auto" style={{ maxWidth: 380 }}>
        <Player
          ref={ref}
          component={Main as unknown as React.ComponentType<Record<string, unknown>>}
          inputProps={props as unknown as Record<string, unknown>}
          durationInFrames={frames}
          fps={project.fps || 30}
          compositionWidth={WIDTH}
          compositionHeight={HEIGHT}
          controls
          loop
          clickToPlay
          doubleClickToFullscreen
          inFrame={range?.in}
          outFrame={range?.out}
          acknowledgeRemotionLicense
          style={{ width: '100%', borderRadius: 18, overflow: 'hidden', background: '#000' }}
          initialFrame={range?.in ?? 0}
        />
      </div>
      {range && <button className="btn w-full mt-3" onClick={clearFocus}>Putar seluruh video</button>}
      <Notice>
        Preview adalah untuk mengecek hasil. Render MP4 final dilakukan <b>manual</b> di terminal Codespaces: <code>npm run render</code> → <code>out/faktaverse-final.mp4</code>. Preview di HP bisa lebih patah dari hasil render.
      </Notice>
    </div>
  );
};
