import React from 'react';
import { ArrowDown, ArrowUp, Play, Trash2 } from 'lucide-react';
import { useProject } from '../state/useProject';
import type { CameraMove, Layout, Scene, SfxName, TextStyle, TransitionType } from '../engine/types';
import { Notice, Range, Select } from './ui';

const LAYOUTS: Layout[] = ['hero', 'blurbg', 'double', 'triple', 'floating', 'tilted', 'cutout', 'pip', 'multilayer', 'typo', 'poster'];
const CAMS: CameraMove[] = ['still', 'zoomIn', 'zoomOut', 'punch', 'shake', 'panH', 'panV', 'rotate', 'parallax', 'whip'];
const TRANS: TransitionType[] = ['cut', 'fade', 'slide', 'whip', 'zoom', 'spin', 'flash', 'glitch'];
const STYLES: TextStyle[] = ['pop', 'bounce', 'shake', 'rotate', 'sticker', 'chars', 'words', 'outline', 'block', 'label'];
const SFX: SfxName[] = ['none', 'pop', 'whoosh', 'impact', 'bass', 'glitch'];
const opt = <T extends string>(a: T[]) => a.map((v) => ({ v, l: v }));

export const ScenePanel: React.FC<{ onPreviewScene: (id: string) => void }> = ({ onPreviewScene }) => {
  const { project, update } = useProject();
  if (!project) return null;
  if (!project.scenes.length) return <Notice>Belum ada scene. Buka tab Gaya lalu tekan AUTOMATIC EDIT.</Notice>;
  const base = `/files/${project.id}/`;
  const patch = (id: string, f: Partial<Scene>) => update((p) => ({ ...p, scenes: p.scenes.map((s) => (s.id === id ? { ...s, ...f } : s)) }));
  const move = (i: number, d: number) => update((p) => { const a = [...p.scenes]; const j = i + d; if (j < 0 || j >= a.length) return p; [a[i], a[j]] = [a[j], a[i]]; return { ...p, scenes: a }; });

  return (
    <div className="pt-2">
      <p className="text-sm text-white/55 mb-3">Koreksi manual bersifat opsional. Perubahan tersimpan otomatis dan dipakai render.</p>
      {project.scenes.map((s, i) => {
        const a = project.assets.find((x) => x.id === s.assetIds[0]);
        return (
          <details key={s.id} className="glass mb-3 overflow-hidden">
            <summary className="flex items-center gap-3 p-3 cursor-pointer list-none">
              <div className="w-12 h-16 rounded-lg overflow-hidden bg-black/50 shrink-0">{a && a.kind === 'image' && <img src={base + a.file} className="w-full h-full object-cover" loading="lazy" />}</div>
              <div className="flex-1 min-w-0"><div className="font-bold">#{i + 1} • {s.layout}</div><div className="text-xs text-white/55">{(s.durationFrames / 30).toFixed(1)}s • {s.camera} • {s.transition}{s.text ? ` • "${s.text}"` : ''}</div></div>
            </summary>
            <div className="p-3 pt-0">
              <Range label="Durasi" value={+(s.durationFrames / 30).toFixed(1)} min={0.4} max={8} step={0.1} onChange={(v) => patch(s.id, { durationFrames: Math.round(v * 30) })} fmt={(v) => `${v}s`} />
              <div className="grid grid-cols-2 gap-x-3">
                <Select label="Layout" value={s.layout} options={opt(LAYOUTS)} onChange={(v) => patch(s.id, { layout: v })} />
                <Select label="Kamera" value={s.camera} options={opt(CAMS)} onChange={(v) => patch(s.id, { camera: v })} />
                <Select label="Transisi" value={s.transition} options={opt(TRANS)} onChange={(v) => patch(s.id, { transition: v, transitionFrames: v === 'cut' || v === 'flash' || v === 'glitch' ? Math.max(s.transitionFrames, v === 'cut' ? 0 : 6) : Math.max(8, s.transitionFrames) })} />
                <Select label="Animasi teks" value={s.textStyle} options={opt(STYLES)} onChange={(v) => patch(s.id, { textStyle: v })} />
                <Select label="Efek suara" value={s.sfx} options={opt(SFX)} onChange={(v) => patch(s.id, { sfx: v })} />
                <Select label="Gambar utama" value={s.assetIds[0] ?? ''} options={project.assets.map((x, k) => ({ v: x.id, l: `${k + 1}. ${x.name.slice(0, 18)}` }))} onChange={(v) => patch(s.id, { assetIds: [v, ...s.assetIds.slice(1)] })} />
              </div>
              <label className="block text-sm text-white/70 mb-1">Teks scene</label>
              <input className="field mb-2" value={s.text ?? ''} onChange={(e) => patch(s.id, { text: e.target.value || undefined })} placeholder="(kosong = tanpa teks)" />
              <Range label="Intensitas scene" value={s.intensity} min={0} max={1} step={0.05} onChange={(v) => patch(s.id, { intensity: v })} fmt={(v) => `${Math.round(v * 100)}%`} />
              <div className="flex gap-2 mt-1 flex-wrap">
                <button className="btn btn-sm" onClick={() => patch(s.id, { glitch: !s.glitch })}>Glitch: {s.glitch ? 'ya' : 'tidak'}</button>
                <button className="btn btn-sm" onClick={() => patch(s.id, { flash: !s.flash })}>Flash: {s.flash ? 'ya' : 'tidak'}</button>
                <button className="btn btn-sm" onClick={() => move(i, -1)}><ArrowUp size={15} /></button>
                <button className="btn btn-sm" onClick={() => move(i, 1)}><ArrowDown size={15} /></button>
                <button className="btn btn-sm" onClick={() => onPreviewScene(s.id)}><Play size={15} />Preview scene</button>
                <button className="btn btn-sm" onClick={() => update((p) => ({ ...p, scenes: p.scenes.filter((x) => x.id !== s.id) }))}><Trash2 size={15} /></button>
              </div>
            </div>
          </details>
        );
      })}
    </div>
  );
};
