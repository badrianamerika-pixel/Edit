import React, { useState } from 'react';
import { Copy, Download, Save } from 'lucide-react';
import { totalFrames } from '../engine/types';
import { useProject } from '../state/useProject';
import { Notice, Section } from './ui';

export const ExportPanel: React.FC = () => {
  const { project, saveNow, status } = useProject();
  const [copied, setCopied] = useState('');
  if (!project) return null;
  const copy = async (t: string) => { try { await navigator.clipboard.writeText(t); setCopied(t); setTimeout(() => setCopied(''), 1500); } catch { prompt('Salin perintah:', t); } };
  const ready = project.scenes.length > 0;
  const used = new Set(project.scenes.flatMap((s) => s.assetIds));
  const cmds = [`npm run render -- ${project.id}`, 'npm run render'];

  return (
    <div className="pt-2">
      <Section title="Status proyek">
        <ul className="text-sm space-y-1 text-white/75">
          <li>{ready ? '✅' : '❌'} Komposisi: {project.scenes.length} scene • {(totalFrames(project) / 30).toFixed(1)} detik</li>
          <li>{project.assets.length ? '✅' : '❌'} {project.assets.length} aset ({used.size} dipakai)</li>
          <li>{project.music ? '✅' : '➖'} Musik {project.music ? '' : '(opsional)'}</li>
          <li>{project.narration ? '✅' : '➖'} Narasi {project.narration ? `• ${project.subtitles.length} subtitle` : '(opsional)'}</li>
          <li>{status === 'saved' ? '✅' : '⏳'} Penyimpanan: {status}</li>
        </ul>
        <button className="btn btn-pri w-full mt-3" onClick={saveNow}><Save size={18} />Simpan sekarang</button>
      </Section>

      <Section title="Render MP4 (manual di Codespaces)" hint="Aplikasi ini tidak pernah merender otomatis. Jalankan di terminal Codespaces setelah proyek tersimpan.">
        {!ready && <Notice kind="warn">Belum ada scene — jalankan AUTOMATIC EDIT dulu.</Notice>}
        {cmds.map((c) => (
          <div key={c} className="flex items-center gap-2 mb-2"><code className="flex-1 field flex items-center overflow-x-auto whitespace-nowrap">{c}</code><button className="btn btn-sm" onClick={() => copy(c)}><Copy size={15} />{copied === c ? 'Tersalin' : 'Salin'}</button></div>
        ))}
        <p className="text-sm text-white/60">Hasil: <code>out/faktaverse-final.mp4</code> (1080×1920, 30fps, H.264/AAC). Unduh lewat Explorer Codespaces → klik kanan → Download. <code>npm run render</code> tanpa argumen memakai proyek yang terakhir disimpan (yang ini).</p>
      </Section>

      <Section title="Cadangan konfigurasi">
        <a className="btn w-full" href={`/api/projects/${project.id}/export`} download><Download size={18} />Ekspor project.json</a>
        <p className="text-xs text-white/45 mt-2">Ekspor hanya konfigurasi (scene, gaya, audio). File aset tetap ada di folder projects/{project.id}/assets.</p>
      </Section>
    </div>
  );
};
