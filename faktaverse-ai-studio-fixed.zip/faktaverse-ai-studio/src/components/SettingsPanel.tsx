import React from 'react';
import { useProject } from '../state/useProject';
import { Range, Section, Select, Toggle } from './ui';

export const SettingsPanel: React.FC = () => {
  const { project, update } = useProject();
  if (!project) return null;
  const a = project.audio, t = project.typography;
  const setA = (f: Partial<typeof a>) => update((p) => ({ ...p, audio: { ...p.audio, ...f } }));
  const setT = (f: Partial<typeof t>) => update((p) => ({ ...p, typography: { ...p.typography, ...f } }));
  const pct = (v: number) => `${Math.round(v * 100)}%`;
  return (
    <div className="pt-2">
      <Section title="Proyek">
        <label className="text-sm text-white/70">Nama</label>
        <input className="field" value={project.name} onChange={(e) => update((p) => ({ ...p, name: e.target.value }))} />
      </Section>
      <Section title="Tipografi & subtitle" hint="Subtitle otomatis ditaruh di area aman 9:16 dan ukuran font menyesuaikan agar tidak overflow.">
        <Select label="Font" value={t.font} options={[{ v: 'anton', l: 'Anton (tebal, sempit)' }, { v: 'montserrat', l: 'Montserrat ExtraBold' }, { v: 'system', l: 'Font sistem' }]} onChange={(v) => setT({ font: v })} />
        <Range label="Ukuran font" value={t.sizeScale} min={0.6} max={1.4} step={0.05} onChange={(v) => setT({ sizeScale: v })} fmt={pct} />
        <Select label="Posisi subtitle" value={t.captionPosition} options={[{ v: 'top', l: 'Atas' }, { v: 'center', l: 'Tengah' }, { v: 'bottom', l: 'Bawah' }]} onChange={(v) => setT({ captionPosition: v })} />
        <Select label="Animasi subtitle" value={t.captionStyle} options={(['pop', 'bounce', 'words', 'chars', 'outline', 'sticker', 'label', 'block', 'shake', 'rotate'] as const).map((v) => ({ v, l: v }))} onChange={(v) => setT({ captionStyle: v })} />
        <Toggle label="Tampilkan judul bar atas" value={t.showTitleBar} onChange={(v) => setT({ showTitleBar: v })} />
      </Section>
      <Section title="Audio">
        <Range label="Volume musik" value={a.musicVolume} min={0} max={1} step={0.05} onChange={(v) => setA({ musicVolume: v })} fmt={pct} />
        <Range label="Volume narasi" value={a.narrationVolume} min={0} max={1} step={0.05} onChange={(v) => setA({ narrationVolume: v })} fmt={pct} />
        <Range label="Volume efek suara" value={a.sfxVolume} min={0} max={1} step={0.05} onChange={(v) => setA({ sfxVolume: v })} fmt={pct} />
        <Range label="Musik saat narasi (ducking)" value={a.duckTo} min={0.05} max={1} step={0.05} onChange={(v) => setA({ duckTo: v })} fmt={pct} />
        <Range label="Fade-in" value={a.fadeInSec} min={0} max={4} step={0.1} onChange={(v) => setA({ fadeInSec: v })} fmt={(v) => `${v}s`} />
        <Range label="Fade-out" value={a.fadeOutSec} min={0} max={5} step={0.1} onChange={(v) => setA({ fadeOutSec: v })} fmt={(v) => `${v}s`} />
        <Toggle label="Efek suara otomatis (whoosh, impact, dll.)" value={a.sfxEnabled} onChange={(v) => setA({ sfxEnabled: v })} />
      </Section>
      <Section title="Render" hint="Dibaca saat npm run render. Turunkan konkurensi jika Codespaces kehabisan memori.">
        <Range label="Konkurensi render" value={project.render.concurrency} min={1} max={4} step={1} onChange={(v) => update((p) => ({ ...p, render: { ...p.render, concurrency: v } }))} />
        <div className="text-sm text-white/55">Format tetap: MP4 • H.264 + AAC • 1080×1920 • 30 FPS</div>
      </Section>
    </div>
  );
};
