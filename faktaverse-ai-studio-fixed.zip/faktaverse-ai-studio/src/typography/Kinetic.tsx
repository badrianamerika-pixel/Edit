import React from 'react';
import { Easing, interpolate, spring, useVideoConfig } from 'remotion';
import type { TextStyle } from '../engine/types';
import { CHAR_W, FONT_STACK, type FontId } from './fonts';

export interface KineticProps {
  text: string;
  keywords?: string[];
  style: TextStyle;
  font: FontId;
  frame: number; // frame lokal sejak teks muncul
  base: number; // ukuran font dasar (px)
  maxWidth?: number;
  maxHeight?: number;
  accent: string;
  accent2: string;
  seed?: number;
  /** frame lokal kemunculan tiap kata (timing kata nyata). Jika kosong: stagger animasi biasa */
  revealFrames?: number[];
  exitAt?: number;
  upper?: boolean;
}

/** Hitung ukuran font terbesar (<= base) agar teks muat di kotak maxWidth x maxHeight. */
export function fitFont(words: string[], font: FontId, base: number, maxW: number, maxH: number): number {
  const cw = CHAR_W[font];
  for (let size = base; size >= 36; size -= 4) {
    let lines = 1, cur = 0;
    for (const w of words) {
      const wl = w.length * cw * size;
      const sp = 0.3 * size;
      if (cur > 0 && cur + sp + wl > maxW) { lines++; cur = wl; } else cur += (cur ? sp : 0) + wl;
      if (wl > maxW) { cur = maxW; lines += 0; }
    }
    if (lines * size * 1.12 <= maxH) return size;
  }
  return 36;
}

const norm = (w: string) => w.toLowerCase().replace(/[^\p{L}\p{N}]/gu, '');

export const Kinetic: React.FC<KineticProps> = ({ text, keywords = [], style, font, frame, base, maxWidth = 920, maxHeight = 520, accent, accent2, seed = 0, revealFrames, exitAt, upper = true }) => {
  const { fps } = useVideoConfig();
  const display = upper && font !== 'system' ? text.toUpperCase() : text;
  const words = display.split(/\s+/).filter(Boolean);
  const size = fitFont(words, font, base, maxWidth, maxHeight);
  const kw = new Set(keywords.map(norm));
  const stroke = Math.max(3, size * 0.07);
  const exit = exitAt !== undefined && frame > exitAt ? Math.max(0, 1 - (frame - exitAt) / 6) : 1;

  const wordEl = (w: string, i: number, charIdx = 0) => {
    const delay = revealFrames ? revealFrames[i] ?? 0 : i * 3;
    const f = frame - delay;
    if (f < 0) return <span key={i} style={{ opacity: 0 }}>{w}&nbsp;</span>;
    const isKw = kw.has(norm(w));
    const sp = spring({ frame: f, fps, config: { damping: style === 'bounce' ? 7 : 11, stiffness: 190, mass: 0.6 } });
    let transform = `scale(${0.4 + 0.6 * sp})`;
    let opacity = Math.min(1, f / 3);
    let color = isKw ? accent2 : '#fff';
    let extra: React.CSSProperties = {};
    switch (style) {
      case 'bounce': transform = `translateY(${(1 - sp) * -90}px) scale(${0.8 + 0.2 * sp})`; break;
      case 'shake': {
        const jx = Math.sin((frame + i) * 4.1 + seed) * 5, jy = Math.cos((frame + i) * 5.3 + seed) * 5;
        transform = `translate(${jx}px, ${jy}px) scale(${0.5 + 0.5 * sp})`; break;
      }
      case 'rotate': transform = `rotate(${(1 - sp) * -35}deg) scale(${0.5 + 0.5 * sp})`; break;
      case 'words': transform = `translateY(${(1 - sp) * 40}px)`; extra = { filter: `blur(${(1 - sp) * 10}px)` }; break;
      case 'outline': color = 'transparent'; extra = { WebkitTextStroke: `${Math.max(2, size * 0.035)}px ${isKw ? accent2 : '#fff'}` }; break;
      case 'chars': break;
      case 'block': color = isKw ? accent2 : '#fff'; break;
      default: break;
    }
    if (style === 'chars') {
      return (
        <span key={i} style={{ display: 'inline-block', whiteSpace: 'nowrap' }}>
          {w.split('').map((c, ci) => {
            const cf = frame - (charIdx + ci) * 1.2;
            const cs = spring({ frame: Math.max(0, cf), fps, config: { damping: 12, stiffness: 220, mass: 0.5 } });
            return <span key={ci} style={{ display: 'inline-block', opacity: cf < 0 ? 0 : 1, transform: `translateY(${(1 - cs) * 30}px) scale(${0.6 + 0.4 * cs})`, color, textShadow: `0 ${size * 0.04}px ${size * 0.12}px rgba(0,0,0,.6)` }}>{c}</span>;
          })}
          &nbsp;
        </span>
      );
    }
    return (
      <span key={i} style={{ display: 'inline-block', transform, opacity, color, margin: `0 ${size * 0.08}px`, whiteSpace: 'nowrap', ...(style === 'outline' ? {} : { WebkitTextStroke: `${stroke}px #000`, paintOrder: 'stroke fill', textShadow: `0 ${size * 0.06}px ${size * 0.14}px rgba(0,0,0,.55)` }), ...extra }}>
        {w}
      </span>
    );
  };

  let ci = 0;
  const els = words.map((w, i) => { const e = wordEl(w, i, ci); ci += w.length; return e; });

  const wrapStyle: React.CSSProperties = {
    fontFamily: FONT_STACK[font], fontWeight: font === 'montserrat' ? 800 : 400, fontSize: size, lineHeight: 1.1,
    textAlign: 'center', maxWidth, display: 'flex', flexWrap: 'wrap', justifyContent: 'center', alignItems: 'center', opacity: exit,
  };

  if (style === 'label' || style === 'sticker' || style === 'block') {
    const pop = spring({ frame, fps, config: { damping: 10, stiffness: 200, mass: 0.6 } });
    const rot = style === 'sticker' ? -4 : style === 'label' ? -2 : 0;
    const bg = style === 'sticker' ? '#fff' : style === 'label' ? accent : 'rgba(0,0,0,.72)';
    const fg = style === 'sticker' ? '#111' : '#fff';
    return (
      <div style={{ ...wrapStyle, background: bg, padding: `${size * 0.14}px ${size * 0.3}px`, borderRadius: style === 'sticker' ? size * 0.25 : style === 'block' ? 6 : 4, transform: `rotate(${rot}deg) scale(${0.3 + 0.7 * pop})`, boxShadow: style === 'sticker' ? `0 ${size * 0.08}px 0 rgba(0,0,0,.35)` : `${size * 0.06}px ${size * 0.06}px 0 rgba(0,0,0,.5)`, border: style === 'sticker' ? `${size * 0.04}px solid #111` : undefined }}>
        {words.map((w, i) => (
          <span key={i} style={{ margin: `0 ${size * 0.08}px`, color: kw.has(norm(w)) ? (style === 'label' ? accent2 : style === 'sticker' ? accent : accent2) : fg, whiteSpace: 'nowrap', opacity: revealFrames ? (frame >= (revealFrames[i] ?? 0) ? 1 : 0) : 1 }}>{w}</span>
        ))}
      </div>
    );
  }
  void Easing; void interpolate;
  return <div style={wrapStyle}>{els}</div>;
};
