import React from 'react';
import { AbsoluteFill } from 'remotion';
import type { Subtitle, TypographyConfig } from '../engine/types';
import type { Preset } from '../engine/presets';
import { Kinetic } from './Kinetic';

const REGION: Record<TypographyConfig['captionPosition'], { top: number; height: number }> = {
  // area aman vertikal 9:16: hindari UI TikTok (atas ~200px, bawah ~380px)
  top: { top: 230, height: 460 },
  center: { top: 740, height: 440 },
  bottom: { top: 1060, height: 480 },
};

export const Captions: React.FC<{ subtitles: Subtitle[]; frame: number; fps: number; typo: TypographyConfig; preset: Preset }> = ({ subtitles, frame, fps, typo, preset }) => {
  const t = frame / fps;
  const sub = subtitles.find((s) => t >= s.start && t < s.end);
  if (!sub) return null;
  const local = frame - Math.round(sub.start * fps);
  const region = REGION[typo.captionPosition];
  // Hanya pakai timing kata jika memang berasal dari transkripsi; selain itu animasi stagger biasa.
  const reveal = sub.timing === 'word' && sub.words?.length === sub.text.split(/\s+/).filter(Boolean).length
    ? sub.words.map((w) => Math.round((w.start - sub.start) * fps)) : undefined;
  const font = typo.font === 'system' ? 'system' : typo.font;
  return (
    <AbsoluteFill style={{ top: region.top, height: region.height, justifyContent: 'center', alignItems: 'center', bottom: 'auto' }}>
      <Kinetic key={sub.id} text={sub.text} keywords={sub.keywords} style={typo.captionStyle} font={font}
        frame={local} base={92 * typo.sizeScale} maxWidth={940} maxHeight={region.height} accent={preset.accent} accent2={preset.accent2}
        seed={sub.id.length} revealFrames={reveal} exitAt={Math.round((sub.end - sub.start) * fps) - 3} />
    </AbsoluteFill>
  );
};
