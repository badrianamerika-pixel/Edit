import '@fontsource/anton/latin-400.css';
import '@fontsource/montserrat/latin-800.css';
import { continueRender, delayRender } from 'remotion';
import { useEffect, useState } from 'react';

export type FontId = 'anton' | 'montserrat' | 'system';
export const FONT_STACK: Record<FontId, string> = {
  anton: "'Anton', Impact, 'Arial Narrow Bold', 'Arial Black', sans-serif",
  montserrat: "'Montserrat', 'Arial Black', 'Helvetica Neue', Arial, sans-serif",
  system: "system-ui, -apple-system, 'Segoe UI', Roboto, Arial, sans-serif",
};
/** rata-rata lebar karakter relatif terhadap ukuran font (dipakai auto-fit agar teks tidak overflow) */
export const CHAR_W: Record<FontId, number> = { anton: 0.46, montserrat: 0.72, system: 0.6 };

/** Menahan render sampai font siap; jika gagal (font hilang) tetap lanjut dengan fallback setelah timeout. */
export function useFontsReady() {
  const [handle] = useState(() => delayRender('fonts', { timeoutInMilliseconds: 30000 }));
  useEffect(() => {
    let done = false;
    const finish = () => { if (!done) { done = true; continueRender(handle); } };
    const t = setTimeout(finish, 8000);
    Promise.all([document.fonts.load("48px 'Anton'"), document.fonts.load("800 48px 'Montserrat'")]).then(finish, finish);
    return () => clearTimeout(t);
  }, [handle]);
}
