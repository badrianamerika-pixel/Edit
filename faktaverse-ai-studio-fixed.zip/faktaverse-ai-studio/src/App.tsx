import React, { useState } from 'react';
import { Download, Home, ImagePlus, Layers, Loader2, Play, Settings, Wand2, CheckCircle2, AlertTriangle } from 'lucide-react';
import { useProject } from './state/useProject';
import { Dashboard } from './components/Dashboard';
import { MediaPanel } from './components/MediaPanel';
import { StylePanel } from './components/StylePanel';
import { ScenePanel } from './components/ScenePanel';
import { PreviewPanel } from './components/PreviewPanel';
import { SettingsPanel } from './components/SettingsPanel';
import { ExportPanel } from './components/ExportPanel';

export type Tab = 'media' | 'style' | 'scenes' | 'preview' | 'settings' | 'export';
const TABS: { id: Tab; label: string; icon: React.ReactNode }[] = [
  { id: 'media', label: 'Media', icon: <ImagePlus size={22} /> },
  { id: 'style', label: 'Gaya', icon: <Wand2 size={22} /> },
  { id: 'scenes', label: 'Scene', icon: <Layers size={22} /> },
  { id: 'preview', label: 'Preview', icon: <Play size={22} /> },
  { id: 'settings', label: 'Atur', icon: <Settings size={22} /> },
  { id: 'export', label: 'Ekspor', icon: <Download size={22} /> },
];

export const App: React.FC = () => {
  const { project, status, statusMsg, close, saveNow } = useProject();
  const [tab, setTab] = useState<Tab>('media');
  const [focusScene, setFocusScene] = useState<string | null>(null);

  if (!project) return <Dashboard />;
  const goPreview = (sceneId: string | null) => { setFocusScene(sceneId); setTab('preview'); };

  return (
    <div className="h-full flex flex-col max-w-3xl mx-auto">
      <header className="safe-t px-4 pt-3 pb-2 flex items-center gap-3">
        <button className="btn btn-sm" onClick={async () => { await saveNow(); close(); }} aria-label="Dashboard"><Home size={18} /></button>
        <div className="min-w-0 flex-1">
          <div className="font-extrabold truncate">{project.name}</div>
          <div className="text-xs text-white/50 truncate">FAKTAVERSE AI STUDIO</div>
        </div>
        <button className="flex items-center gap-1.5 text-xs text-white/70" onClick={saveNow} title={statusMsg}>
          {status === 'saving' || status === 'dirty' ? <Loader2 size={14} className="animate-spin" /> : status === 'error' ? <AlertTriangle size={14} className="text-red-400" /> : <CheckCircle2 size={14} className="text-emerald-400" />}
          {status === 'saving' ? 'Menyimpan…' : status === 'dirty' ? 'Belum tersimpan' : status === 'error' ? 'Gagal simpan' : 'Tersimpan'}
        </button>
      </header>
      {status === 'error' && <div className="mx-4 mb-2 text-sm bg-red-500/15 text-red-200 rounded-xl p-3">{statusMsg}</div>}
      <main className="flex-1 overflow-y-auto px-4 pb-6">
        {tab === 'media' && <MediaPanel goStyle={() => setTab('style')} />}
        {tab === 'style' && <StylePanel onDone={() => goPreview(null)} />}
        {tab === 'scenes' && <ScenePanel onPreviewScene={(id) => goPreview(id)} />}
        {tab === 'preview' && <PreviewPanel focusScene={focusScene} clearFocus={() => setFocusScene(null)} />}
        {tab === 'settings' && <SettingsPanel />}
        {tab === 'export' && <ExportPanel />}
      </main>
      <nav className="safe-b grid grid-cols-6 glass rounded-b-none border-x-0 border-b-0">
        {TABS.map((t) => (
          <button key={t.id} onClick={() => { if (t.id !== 'preview') setFocusScene(null); setTab(t.id); }} className={`flex flex-col items-center gap-0.5 py-2.5 text-[11px] ${tab === t.id ? 'text-fv-acc' : 'text-white/55'}`}>
            {t.icon}{t.label}
          </button>
        ))}
      </nav>
    </div>
  );
};
