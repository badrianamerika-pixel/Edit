import cors from 'cors';
import express, { type NextFunction, type Request, type Response } from 'express';
import fs from 'node:fs';
import path from 'node:path';
import { router } from './routes/projects';
import { PROJECTS_ROOT } from './services/storage';

const app = express();
const PORT = Number(process.env.PORT || 3001);
fs.mkdirSync(PROJECTS_ROOT, { recursive: true });

app.use(cors());
app.use(express.json({ limit: '25mb' }));
app.use('/api', router);
// Aset proyek untuk preview di browser (gambar, audio, video)
app.use('/files', express.static(PROJECTS_ROOT, { fallthrough: false, maxAge: 0, setHeaders: (r) => r.setHeader('Accept-Ranges', 'bytes') }));
app.use('/sounds', express.static(path.resolve(process.cwd(), 'public/sounds')));

const dist = path.resolve(process.cwd(), 'dist');
if (fs.existsSync(dist)) {
  app.use(express.static(dist));
  app.get('*', (_req, res) => res.sendFile(path.join(dist, 'index.html')));
}

app.use((err: Error & { status?: number; code?: string }, _req: Request, res: Response, _next: NextFunction) => {
  const status = err.code === 'LIMIT_FILE_SIZE' ? 413 : err.status ?? 500;
  if (status >= 500) console.error('[server]', err);
  res.status(status).json({ error: err.code === 'LIMIT_FILE_SIZE' ? 'File terlalu besar (maks 500 MB)' : err.message });
});

app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n  FAKTAVERSE API siap di http://localhost:${PORT}`);
  console.log('  Editor: buka port 5173 (npm run preview). Codespaces: forward port 5173 & 3001.\n');
});
