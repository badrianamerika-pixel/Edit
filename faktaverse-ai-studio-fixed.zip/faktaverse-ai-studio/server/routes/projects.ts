import { Router, type Request, type Response, type NextFunction } from 'express';
import multer from 'multer';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { capabilities, fillKeywords, removeBackground, transcribe } from '../services/ai';
import { analyzeBeats, ffmpegAvailable, normalizeAudio, probe, processImage } from '../services/media';
import { createProject, currentProjectId, deleteProject, httpError, listProjects, loadProject, projectDir, saveProject, slug } from '../services/storage';
import { estimateFromScript, parseSrt } from '../../src/engine/subtitles';
import { newProject, type Asset, type Project } from '../../src/engine/types';

const IMG = ['.jpg', '.jpeg', '.png', '.webp', '.avif', '.gif', '.heic'];
const VID = ['.mp4', '.mov', '.webm', '.m4v', '.mkv'];
const AUD = ['.mp3', '.wav', '.m4a', '.aac', '.ogg', '.flac', '.opus'];

const tmpDir = path.join(os.tmpdir(), 'faktaverse-uploads');
fs.mkdirSync(tmpDir, { recursive: true });

const upload = multer({
  dest: tmpDir,
  limits: { fileSize: 500 * 1024 * 1024, files: 60 },
  fileFilter: (req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    const kind = req.params.kind;
    const ok = kind === 'media' ? [...IMG, ...VID].includes(ext) : AUD.includes(ext);
    if (ok) cb(null, true);
    else cb(httpError(415, `Format ${ext || '(tanpa ekstensi)'} tidak didukung untuk "${kind}". Didukung: ${(kind === 'media' ? [...IMG, ...VID] : AUD).join(' ')}`));
  },
});

const wrap = (fn: (req: Request, res: Response) => Promise<unknown> | unknown) => (req: Request, res: Response, next: NextFunction) => {
  Promise.resolve(fn(req, res)).catch(next);
};

export const router = Router();

router.get('/capabilities', wrap(async (_req, res) => {
  res.json({ ...capabilities(), ffmpeg: await ffmpegAvailable(), currentProject: currentProjectId() });
}));

router.get('/projects', wrap((_req, res) => res.json(listProjects())));
router.post('/projects', wrap((req, res) => res.json(createProject(String(req.body?.name ?? '')))));
router.get('/projects/:id', wrap((req, res) => res.json(loadProject(req.params.id))));
router.delete('/projects/:id', wrap((req, res) => { deleteProject(req.params.id); res.json({ ok: true }); }));

router.put('/projects/:id', wrap((req, res) => {
  const body = req.body as Project;
  if (!body || body.id !== req.params.id || !Array.isArray(body.scenes) || !Array.isArray(body.assets)) throw httpError(400, 'Data proyek tidak valid');
  // Aset hanya boleh dirujuk jika filenya ada di disk (mencegah render gagal belakangan)
  const dir = projectDir(body.id);
  const missing = body.assets.filter((a) => !fs.existsSync(path.join(dir, a.file))).map((a) => a.name);
  saveProject(body);
  res.json({ ok: true, updatedAt: body.updatedAt, missing });
}));

router.post('/projects/:id/upload/:kind', upload.array('files', 60), wrap(async (req, res) => {
  const p = loadProject(req.params.id);
  const dir = projectDir(p.id);
  const files = (req.files as Express.Multer.File[]) ?? [];
  if (!files.length) throw httpError(400, 'Tidak ada file yang diunggah');
  const kind = req.params.kind;
  const errors: string[] = [];
  const assetsDir = path.join(dir, 'assets');
  fs.mkdirSync(assetsDir, { recursive: true });
  try {
    for (const f of files) {
      const ext = path.extname(f.originalname).toLowerCase();
      const id = randomBytes(4).toString('hex');
      try {
        if (kind === 'media') {
          if (IMG.includes(ext)) {
            const r = await processImage(f.path, path.join(assetsDir, id));
            p.assets.push({ id, name: f.originalname, kind: 'image', file: `assets/${path.basename(r.file)}`, width: r.width, height: r.height });
          } else {
            const info = await probe(f.path);
            if (!info.width || !info.height || !info.durationSec) throw new Error('video tidak bisa dibaca');
            const dest = path.join(assetsDir, id + ext);
            fs.copyFileSync(f.path, dest);
            p.assets.push({ id, name: f.originalname, kind: 'video', file: `assets/${id}${ext}`, width: info.width, height: info.height, durationSec: info.durationSec });
          }
        } else if (kind === 'music' || kind === 'narration') {
          const n = await normalizeAudio(f.path, path.join(assetsDir, `${kind}-${id}`), kind === 'music' ? -18 : -16);
          const info = await probe(n.file);
          if (!info.durationSec) throw new Error('audio tidak bisa dibaca');
          const audio: NonNullable<Project['music']> = { name: f.originalname, file: `assets/${path.basename(n.file)}`, durationSec: +info.durationSec.toFixed(2), normalized: n.normalized };
          if (kind === 'music') {
            const b = await analyzeBeats(n.file);
            audio.beats = b.beats; audio.bpm = b.bpm;
            p.music = audio;
          } else {
            p.narration = audio;
            p.mode = 'narration';
          }
        } else throw new Error('jenis upload tidak dikenal');
      } catch (e) {
        errors.push(`${f.originalname}: ${(e as Error).message}`);
      }
    }
  } finally {
    for (const f of files) fs.rm(f.path, { force: true }, () => {});
  }
  saveProject(p);
  res.json({ project: p, errors });
}));

router.delete('/projects/:id/assets/:aid', wrap((req, res) => {
  const p = loadProject(req.params.id);
  const a = p.assets.find((x) => x.id === req.params.aid);
  if (!a) throw httpError(404, 'Aset tidak ditemukan');
  for (const f of [a.file, a.cutout]) if (f) fs.rmSync(path.join(projectDir(p.id), f), { force: true });
  p.assets = p.assets.filter((x) => x.id !== a.id);
  p.scenes = p.scenes.map((s) => ({ ...s, assetIds: s.assetIds.filter((i) => i !== a.id) })).filter((s) => s.assetIds.length > 0);
  res.json(saveProject(p));
}));

router.delete('/projects/:id/:kind(music|narration)', wrap((req, res) => {
  const p = loadProject(req.params.id);
  const k = req.params.kind as 'music' | 'narration';
  const a = p[k];
  if (a) fs.rmSync(path.join(projectDir(p.id), a.file), { force: true });
  delete p[k];
  if (k === 'narration') { p.mode = 'music'; p.subtitles = []; }
  res.json(saveProject(p));
}));

router.post('/projects/:id/transcribe', wrap(async (req, res) => {
  const p = loadProject(req.params.id);
  if (!p.narration) throw httpError(400, 'Unggah narasi dulu');
  if (!capabilities().transcribe) throw httpError(501, 'OPENAI_API_KEY belum diatur. Gunakan mode manual: tempel naskah atau SRT.');
  p.subtitles = await transcribe(path.join(projectDir(p.id), p.narration.file));
  res.json(saveProject(p));
}));

router.post('/projects/:id/subtitles', wrap(async (req, res) => {
  const p = loadProject(req.params.id);
  const { script, srt } = req.body as { script?: string; srt?: string };
  if (srt?.trim()) {
    const subs = parseSrt(srt);
    if (!subs.length) throw httpError(400, 'SRT tidak terbaca');
    p.subtitles = await fillKeywords(subs);
  } else if (script?.trim()) {
    if (!p.narration) throw httpError(400, 'Unggah narasi dulu agar durasi diketahui');
    p.narrationScript = script;
    // Timing hanya perkiraan (ditandai "estimated"), bukan timestamp nyata
    p.subtitles = await fillKeywords(estimateFromScript(script, p.narration.durationSec));
  } else throw httpError(400, 'Isi naskah atau SRT');
  res.json(saveProject(p));
}));

router.post('/projects/:id/cutout/:aid', wrap(async (req, res) => {
  const p = loadProject(req.params.id);
  const a = p.assets.find((x) => x.id === req.params.aid);
  if (!a || a.kind !== 'image') throw httpError(404, 'Gambar tidak ditemukan');
  const dir = projectDir(p.id);
  const out = `assets/${a.id}-cutout.png`;
  await removeBackground(path.join(dir, a.file), path.join(dir, out));
  a.cutout = out;
  res.json(saveProject(p));
}));

router.get('/projects/:id/export', wrap((req, res) => {
  const p = loadProject(req.params.id);
  res.setHeader('Content-Disposition', `attachment; filename="${p.id}.faktaverse.json"`);
  res.json(p);
}));

// Impor konfigurasi (aset tidak ikut; aset yang filenya tidak ada akan dilaporkan)
router.post('/import', wrap((req, res) => {
  const src = req.body as Project;
  if (!src || !Array.isArray(src.scenes) || !Array.isArray(src.assets)) throw httpError(400, 'File konfigurasi tidak valid');
  const base = newProject(slug(src.name ?? 'impor'), `${src.name ?? 'Impor'} (impor)`);
  const p: Project = { ...base, ...src, id: base.id, name: base.name, audio: { ...base.audio, ...src.audio }, typography: { ...base.typography, ...src.typography }, render: { ...base.render, ...src.render } };
  saveProject(p);
  const missing = p.assets.filter((a: Asset) => !fs.existsSync(path.join(projectDir(p.id), a.file))).map((a) => a.name);
  res.json({ project: p, missing });
}));
