import fs from 'node:fs';
import path from 'node:path';
import { randomBytes } from 'node:crypto';
import { newProject, totalFrames, type Project } from '../../src/engine/types';

export const PROJECTS_ROOT = path.resolve(process.cwd(), 'projects');
const ID_RE = /^[a-z0-9][a-z0-9-]{1,39}$/;

export function assertId(id: string): string {
  if (!ID_RE.test(id)) throw httpError(400, 'ID proyek tidak valid');
  return id;
}
export function httpError(status: number, message: string) {
  return Object.assign(new Error(message), { status });
}
export const projectDir = (id: string) => path.join(PROJECTS_ROOT, assertId(id));
const jsonPath = (id: string) => path.join(projectDir(id), 'project.json');

export function slug(name: string): string {
  const s = name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 24);
  return `${s || 'proyek'}-${randomBytes(3).toString('hex')}`;
}

export function exists(id: string) { return fs.existsSync(jsonPath(id)); }

export function loadProject(id: string): Project {
  const file = jsonPath(id);
  if (!fs.existsSync(file)) throw httpError(404, `Proyek "${id}" tidak ditemukan`);
  try {
    return JSON.parse(fs.readFileSync(file, 'utf8')) as Project;
  } catch {
    // Pemulihan: file utama rusak (mis. proses mati saat menulis) -> pakai cadangan
    const bak = file + '.bak';
    if (fs.existsSync(bak)) {
      const p = JSON.parse(fs.readFileSync(bak, 'utf8')) as Project;
      fs.copyFileSync(bak, file);
      return p;
    }
    throw httpError(500, 'project.json rusak dan tidak ada cadangan');
  }
}

export function saveProject(p: Project, markCurrent = true): Project {
  const dir = projectDir(p.id);
  fs.mkdirSync(path.join(dir, 'assets'), { recursive: true });
  p.updatedAt = new Date().toISOString();
  const file = jsonPath(p.id);
  const tmp = file + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(p, null, 2));
  if (fs.existsSync(file)) fs.copyFileSync(file, file + '.bak');
  fs.renameSync(tmp, file);
  if (markCurrent) fs.writeFileSync(path.join(PROJECTS_ROOT, '.current'), p.id);
  return p;
}

export function createProject(name: string): Project {
  const p = newProject(slug(name), name.trim() || 'Proyek Baru');
  return saveProject(p);
}

export function deleteProject(id: string) {
  fs.rmSync(projectDir(id), { recursive: true, force: true });
}

export function listProjects() {
  fs.mkdirSync(PROJECTS_ROOT, { recursive: true });
  return fs.readdirSync(PROJECTS_ROOT, { withFileTypes: true })
    .filter((d) => d.isDirectory() && fs.existsSync(path.join(PROJECTS_ROOT, d.name, 'project.json')))
    .map((d) => {
      try {
        const p = loadProject(d.name);
        const thumb = p.assets.find((a) => a.kind === 'image');
        return { id: p.id, name: p.name, updatedAt: p.updatedAt, preset: p.preset, assets: p.assets.length, scenes: p.scenes.length, seconds: +(totalFrames(p) / (p.fps || 30)).toFixed(1), thumb: thumb ? `/files/${p.id}/${thumb.file}` : null };
      } catch { return null; }
    })
    .filter(Boolean)
    .sort((a, b) => (b!.updatedAt > a!.updatedAt ? 1 : -1));
}

export function currentProjectId(): string | null {
  const f = path.join(PROJECTS_ROOT, '.current');
  if (fs.existsSync(f)) {
    const id = fs.readFileSync(f, 'utf8').trim();
    if (ID_RE.test(id) && exists(id)) return id;
  }
  const list = listProjects();
  return list.length ? list[0]!.id : null;
}
