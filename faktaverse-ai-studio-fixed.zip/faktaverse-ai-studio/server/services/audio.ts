/** Deteksi beat sederhana: onset kick (low-band) + peak picking + estimasi BPM. Murni JS, tanpa dependensi. */
export function detectBeats(samples: Int16Array, sr: number): { beats: number[]; bpm?: number } {
  const hop = 256, win = 1024;
  const n = Math.floor((samples.length - win) / hop);
  if (n < 20) return { beats: [] };
  // low-pass sederhana (moving average 8) untuk menonjolkan kick/bass
  const env = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    let e = 0;
    const s0 = i * hop;
    let acc = 0;
    for (let j = 0; j < win; j++) {
      acc += samples[s0 + j] / 32768;
      if (j >= 8) acc -= samples[s0 + j - 8] / 32768;
      const v = acc / 8;
      e += v * v;
    }
    env[i] = Math.sqrt(e / win);
  }
  const onset = new Float32Array(n);
  for (let i = 1; i < n; i++) onset[i] = Math.max(0, env[i] - env[i - 1]);
  const fr = sr / hop; // frame per detik
  const w = Math.round(fr); // jendela rata-rata 1 detik
  const beats: number[] = [];
  let last = -1;
  const minGap = Math.round(fr * 0.25);
  let pre = 0;
  const prefix = new Float64Array(n + 1);
  for (let i = 0; i < n; i++) prefix[i + 1] = prefix[i] + onset[i];
  for (let i = 3; i < n - 3; i++) {
    const a = Math.max(0, i - w), b = Math.min(n, i + w);
    const mean = (prefix[b] - prefix[a]) / (b - a);
    const isPeak = onset[i] >= onset[i - 1] && onset[i] > onset[i + 1] && onset[i] > onset[i - 2] && onset[i] > onset[i + 2];
    if (isPeak && onset[i] > mean * 1.8 + 1e-4 && (last < 0 || i - last >= minGap)) {
      beats.push(+(i / fr).toFixed(3));
      last = i;
    }
    pre = i;
  }
  void pre;
  // BPM via autokorelasi pada envelope onset (lag 0.3s..1.0s)
  let best = 0, bestLag = 0;
  for (let lag = Math.round(fr * 0.3); lag <= Math.round(fr * 1.0); lag++) {
    let sum = 0;
    for (let i = lag; i < n; i++) sum += onset[i] * onset[i - lag];
    if (sum > best) { best = sum; bestLag = lag; }
  }
  let bpm = bestLag ? 60 / (bestLag / fr) : undefined;
  if (bpm) { while (bpm < 80) bpm *= 2; while (bpm > 180) bpm /= 2; bpm = Math.round(bpm); }
  return { beats, bpm };
}
