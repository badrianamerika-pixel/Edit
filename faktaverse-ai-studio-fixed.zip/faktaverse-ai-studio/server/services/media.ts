import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import ffmpegStatic from 'ffmpeg-static';
import { detectBeats } from './audio';

export const FFMPEG: string = process.env.FFMPEG_PATH || (ffmpegStatic as unknown as string) || 'ffmpeg';

export function run(cmd: string, args: string[], opts: { collectStdout?: boolean } = {}): Promise<{ code: number; stdout: Buffer; stderr: string }> {
  return new Promise((resolve, reject) => {
    const ps = spawn(cmd, args, { stdio: ['ignore', 'pipe', 'pipe'] });
    const out: Buffer[] = [];
    let err = '';
    ps.stdout.on('data', (d) => { if (opts.collectStdout) out.push(d); });
    ps.stderr.on('data', (d) => { err += d.toString(); if (err.length > 200000) err = err.slice(-100000); });
    ps.on('error', (e) => reject(new Error(`Tidak bisa menjalankan ${cmd}: ${e.message}`)));
    ps.on('close', (code) => resolve({ code: code ?? -1, stdout: Buffer.concat(out), stderr: err }));
  });
}

export async function ffmpegAvailable(): Promise<boolean> {
  try { const r = await run(FFMPEG, ['-version']); return r.code === 0; } catch { return false; }
}

/** Probe via `ffmpeg -i` (tidak butuh ffprobe). */
export async function probe(file: string): Promise<{ durationSec: number; width?: number; height?: number }> {
  const r = await run(FFMPEG, ['-hide_banner', '-i', file]);
  const d = r.stderr.match(/Duration:\s*(\d+):(\d+):(\d+(?:\.\d+)?)/);
  const durationSec = d ? +d[1] * 3600 + +d[2] * 60 + +d[3] : 0;
  const v = r.stderr.match(/Video:.*?,\s*(\d{2,5})x(\d{2,5})/);
  return { durationSec, width: v ? +v[1] : undefined, height: v ? +v[2] : undefined };
}

export async function processImage(src: string, destNoExt: string): Promise<{ file: string; width: number; height: number }> {
  const meta = await sharp(src, { failOn: 'none' }).metadata();
  const alpha = !!meta.hasAlpha && (meta.format === 'png' || meta.format === 'webp' || meta.format === 'gif');
  const ext = alpha ? '.png' : '.jpg';
  const dest = destNoExt + ext;
  // Perkecil gambar raksasa (hemat memori saat render). Tidak pernah diperbesar.
  let pipe = sharp(src, { failOn: 'none', limitInputPixels: 268402689 }).rotate().resize({ width: 2160, height: 2160, fit: 'inside', withoutEnlargement: true });
  pipe = alpha ? pipe.png({ compressionLevel: 8 }) : pipe.jpeg({ quality: 88, mozjpeg: true });
  const info = await pipe.toFile(dest);
  return { file: dest, width: info.width, height: info.height };
}

export async function normalizeAudio(src: string, destNoExt: string, lufs: number): Promise<{ file: string; normalized: boolean }> {
  const out = destNoExt + '.m4a';
  const r = await run(FFMPEG, ['-y', '-hide_banner', '-i', src, '-vn', '-af', `loudnorm=I=${lufs}:TP=-1.5:LRA=11`, '-ar', '44100', '-ac', '2', '-c:a', 'aac', '-b:a', '192k', out]);
  if (r.code === 0 && fs.existsSync(out) && fs.statSync(out).size > 1000) return { file: out, normalized: true };
  // fallback: pakai berkas asli apa adanya (Remotion tetap bisa memutar mp3/wav/m4a)
  const ext = path.extname(src).toLowerCase() || '.mp3';
  const raw = destNoExt + ext;
  fs.copyFileSync(src, raw);
  return { file: raw, normalized: false };
}

export async function analyzeBeats(file: string): Promise<{ beats: number[]; bpm?: number }> {
  const sr = 11025;
  const r = await run(FFMPEG, ['-v', 'error', '-i', file, '-t', '600', '-ac', '1', '-ar', String(sr), '-f', 's16le', '-'], { collectStdout: true });
  if (r.code !== 0 || r.stdout.length < sr * 2) return { beats: [] };
  const buf = r.stdout;
  const samples = new Int16Array(buf.buffer, buf.byteOffset, Math.floor(buf.length / 2));
  return detectBeats(samples, sr);
}
