import fs from 'node:fs';
import { heuristicKeywords } from '../../src/engine/subtitles';
import type { Subtitle } from '../../src/engine/types';

export const capabilities = () => ({
  transcribe: !!process.env.OPENAI_API_KEY,
  keywords: !!process.env.ANTHROPIC_API_KEY,
  cutout: !!process.env.REMOVEBG_API_KEY,
});

/** Transkripsi dengan timestamp kata (OpenAI Whisper). Hanya dipanggil jika OPENAI_API_KEY ada. */
export async function transcribe(file: string): Promise<Subtitle[]> {
  const key = process.env.OPENAI_API_KEY;
  if (!key) throw new Error('OPENAI_API_KEY belum diatur');
  const form = new FormData();
  form.append('file', new Blob([fs.readFileSync(file)]), 'narration' + (file.match(/\.[a-z0-9]+$/i)?.[0] ?? '.m4a'));
  form.append('model', 'whisper-1');
  form.append('response_format', 'verbose_json');
  form.append('timestamp_granularities[]', 'word');
  form.append('timestamp_granularities[]', 'segment');
  const res = await fetch('https://api.openai.com/v1/audio/transcriptions', { method: 'POST', headers: { Authorization: `Bearer ${key}` }, body: form });
  if (!res.ok) throw new Error(`Transkripsi gagal (${res.status}): ${(await res.text()).slice(0, 300)}`);
  const j = (await res.json()) as { segments?: { start: number; end: number; text: string }[]; words?: { word: string; start: number; end: number }[] };
  const words = j.words ?? [];
  const subs: Subtitle[] = (j.segments ?? []).map((s, i) => {
    const ws = words.filter((w) => w.start >= s.start - 0.05 && w.end <= s.end + 0.05).map((w) => ({ w: w.word.trim(), start: w.start, end: w.end })).filter((w) => w.w);
    const hasWords = ws.length > 0;
    const text = hasWords ? ws.map((w) => w.w).join(' ') : s.text.trim();
    return { id: `s${i}`, start: s.start, end: s.end, text, keywords: [], timing: hasWords ? 'word' : 'sentence', words: hasWords ? ws : undefined } as Subtitle;
  });
  return fillKeywords(subs);
}

/** Kata kunci selalu berasal dari teks narasi sendiri (divalidasi); tanpa key / gagal -> heuristik lokal. */
export async function fillKeywords(subs: Subtitle[]): Promise<Subtitle[]> {
  const key = process.env.ANTHROPIC_API_KEY;
  let result: string[][] | null = null;
  if (key && subs.length) {
    try {
      const res = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'x-api-key': key, 'anthropic-version': '2023-06-01', 'content-type': 'application/json' },
        body: JSON.stringify({
          model: 'claude-sonnet-4-6', max_tokens: 2000,
          messages: [{ role: 'user', content: `Untuk setiap kalimat narasi berikut, pilih 1-3 kata PENTING (kata persis seperti tertulis di kalimat itu) untuk di-highlight di subtitle video. Balas HANYA JSON array of array string, panjang array sama dengan jumlah kalimat.\n${JSON.stringify(subs.map((s) => s.text))}` }],
        }),
      });
      if (res.ok) {
        const j = (await res.json()) as { content?: { type: string; text?: string }[] };
        const txt = (j.content ?? []).map((c) => c.text ?? '').join('').replace(/```json|```/g, '').trim();
        const arr = JSON.parse(txt);
        if (Array.isArray(arr) && arr.length === subs.length) result = arr;
      }
    } catch { /* jatuh ke heuristik */ }
  }
  return subs.map((s, i) => {
    const cand = result?.[i];
    const lower = s.text.toLowerCase();
    const valid = Array.isArray(cand) ? cand.filter((w) => typeof w === 'string' && lower.includes(w.toLowerCase())) : [];
    return { ...s, keywords: valid.length ? valid : heuristicKeywords(s.text) };
  });
}

export async function removeBackground(src: string, dest: string): Promise<void> {
  const key = process.env.REMOVEBG_API_KEY;
  if (!key) throw Object.assign(new Error('Layanan background-removal belum dikonfigurasi (REMOVEBG_API_KEY). Memakai layering biasa.'), { status: 501 });
  const form = new FormData();
  form.append('image_file', new Blob([fs.readFileSync(src)]), 'image.jpg');
  form.append('size', 'auto');
  form.append('format', 'png');
  const res = await fetch('https://api.remove.bg/v1.0/removebg', { method: 'POST', headers: { 'X-Api-Key': key }, body: form });
  if (!res.ok) throw new Error(`remove.bg gagal (${res.status}): ${(await res.text()).slice(0, 200)}`);
  fs.writeFileSync(dest, Buffer.from(await res.arrayBuffer()));
}
