export default {
  content: ['./index.html', './src/**/*.{ts,tsx}'],
  theme: { extend: { colors: { fv: { bg: '#0b0d14', card: 'rgba(255,255,255,0.06)', acc: '#ff2d55', acc2: '#ffd60a' } } } },
  plugins: [],
};
