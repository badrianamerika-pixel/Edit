#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/.."
echo "[FaktaVerse] Preparing Codespaces environment..."
node --version
npm --version
if ! command -v ffmpeg >/dev/null 2>&1; then
  echo "[FaktaVerse] Installing FFmpeg..."
  sudo apt-get update
  sudo apt-get install -y ffmpeg
fi
if [ -f package-lock.json ]; then npm ci; else npm install; fi
npm run setup
echo "[FaktaVerse] Preparing Remotion browser..."
npx remotion browser ensure
echo "[FaktaVerse] Setup complete. Run: npm run doctor && npm run preview"
