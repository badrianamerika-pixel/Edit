/**
 * Render manual: `npm run render` (proyek terakhir disimpan) atau `npm run render -- <id-proyek>`.
 * Output: out/faktaverse-final.mp4 (H.264 + AAC, 1080x1920, 30fps). Tanpa cloud, tanpa GPU.
 */
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { bundle } from '@remotion/bundler';
import { renderMedia, selectComposition } from '@remotion/renderer';
import { currentProjectId, loadProject, projectDir } from '../server/services/storage';
import { totalFrames } from '../src/engine/types';

const fail = (msg: string): never => { console.error(`\n✖ ${msg}\n`); process.exit(1); };
const root = process.cwd();

async function main() {
  const id = process.argv[2] || currentProjectId() || fail('Tidak ada proyek. Buat proyek di editor (npm run preview) atau jalankan: npm run render:demo');
  let project;
  try { project = loadProject(id); } catch (e) { return fail(`Gagal memuat proyek "${id}": ${(e as Error).message}`); }
  if (!project.scenes.length) fail(`Proyek "${project.name}" belum punya scene. Buka editor → klik AUTOMATIC EDIT → simpan.`);

  const dir = projectDir(id);
  const needed = new Set<string>();
  for (const a of project.assets) { needed.add(a.file); if (a.cutout) needed.add(a.cutout); }
  if (project.music) needed.add(project.music.file);
  if (project.narration) needed.add(project.narration.file);
  const used = new Set(project.scenes.flatMap((s) => s.assetIds));
  const missing = [...needed].filter((f) => !fs.existsSync(path.join(dir, f)));
  const missingUsed = project.assets.filter((a) => used.has(a.id) && missing.includes(a.file));
  if (missingUsed.length) fail(`File aset hilang di projects/${id}/: ${missingUsed.map((a) => a.file).join(', ')}\nUnggah ulang aset tersebut atau hapus dari scene.`);
  if (project.music && missing.includes(project.music.file)) fail(`File musik hilang: projects/${id}/${project.music.file}`);
  if (project.narration && missing.includes(project.narration.file)) fail(`File narasi hilang: projects/${id}/${project.narration.file}`);

  // Folder publik sementara = aset proyek + sounds (Remotion memakai staticFile dari sini)
  const pub = path.join(root, '.render-cache', 'public');
  fs.rmSync(pub, { recursive: true, force: true });
  fs.mkdirSync(pub, { recursive: true });
  fs.cpSync(path.join(dir, 'assets'), path.join(pub, 'assets'), { recursive: true });
  const snd = path.join(root, 'public/sounds');
  if (!fs.existsSync(path.join(snd, 'whoosh.wav'))) fail('Efek suara belum dibuat. Jalankan: npm run setup');
  fs.cpSync(snd, path.join(pub, 'sounds'), { recursive: true });

  const frames = totalFrames(project);
  const fps = project.fps || 30;
  const out = path.resolve(root, project.render?.output || 'out/faktaverse-final.mp4');
  fs.mkdirSync(path.dirname(out), { recursive: true });
  // Konkurensi dibatasi agar muat di memori Codespaces (default 2). Override: RENDER_CONCURRENCY=1 npm run render
  const concurrency = Math.max(1, Number(process.env.RENDER_CONCURRENCY) || Math.min(project.render?.concurrency || 2, Math.max(1, os.cpus().length - 1)));
  console.log(`\n▶ Proyek: ${project.name} (${id})\n  ${project.scenes.length} scene • ${(frames / fps).toFixed(1)} dtk • ${frames} frame • konkurensi ${concurrency}\n  Output: ${out}\n`);

  console.log('… membundel komposisi');
  const serveUrl = await bundle({ entryPoint: path.join(root, 'src/remotion/index.ts'), publicDir: pub, onProgress: () => {} });
  const inputProps = { project };
  const composition = await selectComposition({ serveUrl, id: 'Faktaverse', inputProps }).catch((e) => fail(`Gagal memuat komposisi: ${e.message}`));
  let last = -1;
  const t0 = Date.now();
  await renderMedia({
    composition, serveUrl, inputProps, outputLocation: out,
    codec: 'h264', audioCodec: 'aac', imageFormat: 'jpeg', jpegQuality: 90, crf: 20, pixelFormat: 'yuv420p',
    concurrency, overwrite: true, timeoutInMilliseconds: 120000,
    onProgress: ({ progress }) => {
      const pct = Math.floor(progress * 100);
      if (pct !== last && pct % 5 === 0) { last = pct; process.stdout.write(`\r  render ${pct}%  (${((Date.now() - t0) / 1000).toFixed(0)}s)`); }
    },
  });
  const mb = (fs.statSync(out).size / 1048576).toFixed(1);
  console.log(`\n\n✔ Selesai: ${out} (${mb} MB)\n  Unduh dari panel Explorer Codespaces: klik kanan out/faktaverse-final.mp4 → Download.\n`);
}

main().catch((e) => fail(`Render gagal: ${e?.message ?? e}\nTips: coba RENDER_CONCURRENCY=1 npm run render; pastikan npm install selesai dan Chrome Headless terunduh (npx remotion browser ensure).`));
