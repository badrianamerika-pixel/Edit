import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { execFileSync } from 'node:child_process';

const root = process.cwd();
let failed = false;
const check = (label: string, ok: boolean, detail = '') => {
  console.log(`${ok ? '✔' : '✖'} ${label}${detail ? ` — ${detail}` : ''}`);
  if (!ok) failed = true;
};
const version = (bin: string, args: string[]) => {
  try { return execFileSync(bin, args, { encoding: 'utf8', stdio: ['ignore', 'pipe', 'ignore'] }).trim().split('\n')[0]; }
  catch { return ''; }
};

console.log('\nFAKTAVERSE AI STUDIO — ENVIRONMENT CHECK\n');
check('Node.js', Number(process.versions.node.split('.')[0]) >= 20, process.version);
check('npm', Boolean(version('npm', ['--version'])), version('npm', ['--version']));
check('FFmpeg', Boolean(version('ffmpeg', ['-version'])), version('ffmpeg', ['-version']));
check('package.json', fs.existsSync(path.join(root, 'package.json')));
check('Remotion entry', fs.existsSync(path.join(root, 'src/remotion/index.ts')));
check('Project storage', fs.existsSync(path.join(root, 'projects')));
check('Public sounds', fs.existsSync(path.join(root, 'public/sounds')));
check('Output directory', fs.existsSync(path.join(root, 'out')));
check('Available memory', os.freemem() > 512 * 1024 * 1024, `${Math.round(os.freemem() / 1024 / 1024)} MB free`);

if (failed) {
  console.log('\nSome checks failed. Review the messages above before rendering.\n');
  process.exitCode = 1;
} else {
  console.log('\nEnvironment looks ready. Start the editor with: npm run preview\nRender manually with: npm run render:demo\n');
}
