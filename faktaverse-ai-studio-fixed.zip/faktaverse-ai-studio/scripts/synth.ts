import fs from 'node:fs';

export function writeWav(file: string, data: Float32Array, sr: number) {
  let peak = 0;
  for (const v of data) peak = Math.max(peak, Math.abs(v));
  const g = peak > 0 ? 0.9 / peak : 1;
  const buf = Buffer.alloc(44 + data.length * 2);
  buf.write('RIFF', 0); buf.writeUInt32LE(36 + data.length * 2, 4); buf.write('WAVEfmt ', 8);
  buf.writeUInt32LE(16, 16); buf.writeUInt16LE(1, 20); buf.writeUInt16LE(1, 22);
  buf.writeUInt32LE(sr, 24); buf.writeUInt32LE(sr * 2, 28); buf.writeUInt16LE(2, 32); buf.writeUInt16LE(16, 34);
  buf.write('data', 36); buf.writeUInt32LE(data.length * 2, 40);
  for (let i = 0; i < data.length; i++) buf.writeInt16LE(Math.max(-32768, Math.min(32767, Math.round(data[i] * g * 32767))), 44 + i * 2);
  fs.writeFileSync(file, buf);
}

const SR = 44100;
let seed = 7;
const rnd = () => { seed = (seed * 1664525 + 1013904223) >>> 0; return seed / 4294967296 * 2 - 1; };

export function whoosh(): Float32Array {
  const n = Math.floor(SR * 0.6), o = new Float32Array(n);
  let y = 0;
  for (let i = 0; i < n; i++) {
    const t = i / n;
    const a = 0.02 + 0.5 * Math.sin(Math.PI * t) ** 2;
    y += a * (rnd() - y);
    o[i] = y * Math.sin(Math.PI * t) ** 1.5 * 3;
  }
  return o;
}
export function impact(): Float32Array {
  const n = Math.floor(SR * 0.9), o = new Float32Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (38 + 90 * Math.exp(-t * 14))) / SR;
    o[i] = Math.sin(ph) * Math.exp(-t * 4.5) + rnd() * Math.exp(-t * 40) * 0.6;
  }
  return o;
}
export function bass(): Float32Array {
  const n = Math.floor(SR * 0.7), o = new Float32Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (52 + 40 * Math.exp(-t * 20))) / SR;
    o[i] = Math.tanh(Math.sin(ph) * 2.2) * Math.exp(-t * 5);
  }
  return o;
}
export function pop(): Float32Array {
  const n = Math.floor(SR * 0.16), o = new Float32Array(n);
  let ph = 0;
  for (let i = 0; i < n; i++) {
    const t = i / SR;
    ph += (2 * Math.PI * (220 + 700 * Math.exp(-t * 45))) / SR;
    o[i] = Math.sin(ph) * Math.exp(-t * 28);
  }
  return o;
}
export function glitch(): Float32Array {
  const n = Math.floor(SR * 0.35), o = new Float32Array(n);
  let hold = 0;
  for (let i = 0; i < n; i++) {
    if (i % (30 + ((i / 2000) | 0) * 17) === 0) hold = rnd();
    const gate = Math.sin(i / 300) > -0.2 ? 1 : 0;
    o[i] = Math.round(hold * 6) / 6 * gate * (1 - i / n);
  }
  return o;
}

/** Musik demo 120 BPM: kick tiap beat, hat tiap 1/2 beat, bass line sederhana. */
export function demoMusic(seconds: number): { data: Float32Array; sr: number } {
  const sr = 22050, n = sr * seconds, o = new Float32Array(n), beat = 0.5;
  const notes = [55, 55, 65.4, 49];
  for (let i = 0; i < n; i++) {
    const t = i / sr;
    const bt = t % beat;
    const kick = Math.sin(2 * Math.PI * (45 * bt + 90 * (1 - Math.exp(-bt * 30)) / 30)) * Math.exp(-bt * 12);
    const ht = (t + beat / 2) % beat;
    const hat = (Math.sin(i * 12.9898) * 43758.5453 % 1) * Math.exp(-ht * 90) * 0.18;
    const bar = Math.floor(t / (beat * 4)) % 4;
    const bs = Math.sin(2 * Math.PI * notes[bar] * t) * 0.28 * (0.6 + 0.4 * Math.sin(t * 2 * Math.PI * 2));
    o[i] = kick * 0.9 + hat + bs;
  }
  return { data: o, sr };
}
