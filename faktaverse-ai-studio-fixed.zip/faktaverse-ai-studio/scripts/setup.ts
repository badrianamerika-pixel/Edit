import fs from 'node:fs';
import path from 'node:path';
import sharp from 'sharp';
import { autoEdit } from '../src/engine/autoEdit';
import { newProject, type Asset } from '../src/engine/types';
import { detectBeats } from '../server/services/audio';
import { bass, demoMusic, glitch, impact, pop, whoosh, writeWav } from './synth';

const root = process.cwd();
const soundsDir = path.join(root, 'public/sounds');
fs.mkdirSync(soundsDir, { recursive: true });
const sfx = { whoosh, impact, bass, pop, glitch } as const;
for (const [name, fn] of Object.entries(sfx)) {
  const f = path.join(soundsDir, `${name}.wav`);
  if (!fs.existsSync(f)) { writeWav(f, fn(), 44100); console.log('[setup] suara dibuat:', name); }
}

async function demo() {
  const dir = path.join(root, 'projects/demo');
  const pj = path.join(dir, 'project.json');
  if (fs.existsSync(pj)) return;
  fs.mkdirSync(path.join(dir, 'assets'), { recursive: true });
  const palette = [['#ff2d55', '#ffd60a'], ['#0a84ff', '#30d158'], ['#bf5af2', '#ff9f0a'], ['#ff453a', '#64d2ff'], ['#30d158', '#0a84ff'], ['#ffd60a', '#bf5af2'], ['#64d2ff', '#ff375f']];
  const dims: [number, number][] = [[1080, 1920], [1920, 1080], [1080, 1920], [1600, 1200], [1080, 1920], [1920, 1080], [1080, 1350]];
  const assets: Asset[] = [];
  for (let i = 0; i < 7; i++) {
    const [w, h] = dims[i];
    const [c1, c2] = palette[i];
    // Gambar sampel dibuat lokal (bentuk geometris, tanpa teks/font) agar demo tidak bergantung aset eksternal
    const shapes = Array.from({ length: 9 }, (_, k) => `<circle cx="${(k * 137 + i * 53) % w}" cy="${(k * 211 + i * 97) % h}" r="${60 + ((k * 41 + i * 13) % 160)}" fill="${k % 2 ? c1 : c2}" opacity="0.55"/>`).join('');
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="${w}" height="${h}"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="${c1}"/><stop offset="1" stop-color="${c2}"/></linearGradient></defs><rect width="100%" height="100%" fill="url(#g)"/>${shapes}<rect x="${w * 0.18}" y="${h * 0.3}" width="${w * 0.64}" height="${h * 0.4}" rx="${Math.min(w, h) * 0.06}" fill="#000" opacity="0.35"/><circle cx="${w / 2}" cy="${h / 2}" r="${Math.min(w, h) * 0.14}" fill="#fff" opacity="0.9"/></svg>`;
    const file = `assets/sample-${i + 1}.jpg`;
    const info = await sharp(Buffer.from(svg)).jpeg({ quality: 88 }).toFile(path.join(dir, file));
    assets.push({ id: `demo${i + 1}`, name: `sample-${i + 1}.jpg`, kind: 'image', file, width: info.width, height: info.height });
  }
  const m = demoMusic(32);
  writeWav(path.join(dir, 'assets/music.wav'), m.data, m.sr);
  const pcm = new Int16Array(m.data.length);
  for (let i = 0; i < pcm.length; i++) pcm[i] = Math.round(Math.max(-1, Math.min(1, m.data[i])) * 32767);
  const { beats, bpm } = detectBeats(pcm, m.sr);
  const p = newProject('demo', 'Demo 30 detik');
  p.title = 'FAKTAVERSE DEMO';
  p.assets = assets;
  p.music = { name: 'music.wav (sintetis)', file: 'assets/music.wav', durationSec: 32, beats, bpm, normalized: false };
  p.maxSeconds = 30;
  p.textLines = ['TAHUKAH KAMU?', '', 'FAKTA #1', '', 'GILA SIH', '', '', 'JANGAN SKIP'];
  p.scenes = autoEdit(p);
  fs.writeFileSync(pj, JSON.stringify(p, null, 2));
  console.log(`[setup] proyek demo dibuat (${p.scenes.length} scene, ${beats.length} beat terdeteksi, ~${bpm} BPM)`);
}
demo().catch((e) => console.error('[setup] demo gagal:', e.message));
