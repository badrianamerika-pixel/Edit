import { autoEdit, targetSeconds } from '../src/engine/autoEdit.ts';
import { newProject } from '../src/engine/types.ts';
import { PRESETS as P } from '../src/engine/presets.ts';
import { estimateFromScript, parseSrt } from '../src/engine/subtitles.ts';

const p = newProject('t', 't');
p.assets = Array.from({ length: 7 }, (_, i) => ({ id: 'a' + i, name: 'x' + i, kind: 'image' as const, file: `assets/${i}.jpg`, width: i % 2 ? 1080 : 1920, height: i % 2 ? 1920 : 1080 }));
p.music = { name: 'm', file: 'assets/m.m4a', durationSec: 30, beats: Array.from({ length: 60 }, (_, i) => i * 0.5) };
p.textLines = ['HALO', '', 'FAKTA 1'];
let fails = 0;
const ok = (c: boolean, m: string) => { if (!c) { fails++; console.error('FAIL', m); } else console.log('ok  ', m); };
for (const id of Object.keys(P) as (keyof typeof P)[]) {
  p.preset = id;
  const s = autoEdit(p);
  const a = autoEdit(p);
  const frames = s.reduce((x, y) => x + y.durationFrames, 0);
  ok(JSON.stringify(s) === JSON.stringify(a), `${id}: deterministik`);
  ok(Math.abs(frames / 30 - targetSeconds(p)) < 1.5, `${id}: durasi ${(frames / 30).toFixed(1)}s ~ target`);
  ok(new Set(s.map((x) => x.layout)).size >= 2, `${id}: layout bervariasi (${[...new Set(s.map((x) => x.layout))].join(',')})`);
  ok(s.every((x) => x.layout !== 'typo' || !!x.text), `${id}: typo selalu punya teks`);
  ok(s.every((x, i) => i === 0 || x.camera !== s[i - 1].camera), `${id}: kamera tidak berulang berurutan`);
}
const sub = estimateFromScript('Halo dunia. Ini 1453 Konstantinopel jatuh!', 10);
ok(sub.length === 2 && sub[1].timing === 'estimated', 'script -> estimated');
ok(parseSrt('1\n00:00:01,000 --> 00:00:03,500\nTes kalimat\n').length === 1, 'srt parse');
process.exit(fails ? 1 : 0);
