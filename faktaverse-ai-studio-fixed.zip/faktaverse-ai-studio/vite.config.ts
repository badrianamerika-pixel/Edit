import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Di Codespaces, port 5173 (editor) dan 3001 (API) harus di-forward. Proxy ini membuat
// browser hanya perlu mengakses port 5173.
export default defineConfig({
  plugins: [react()],
  server: {
    host: true,
    port: 5173,
    allowedHosts: true,
    proxy: {
      '/api': 'http://localhost:3001',
      '/files': 'http://localhost:3001',
    },
  },
  build: { outDir: 'dist', chunkSizeWarningLimit: 1500 },
});
