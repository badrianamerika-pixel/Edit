# FAKTAVERSE AI STUDIO

Editor video otomatis bergaya TikTok (React + Vite + Remotion + Express). Alur:

**Upload media → AUTOMATIC EDIT → Preview → Simpan → Render manual di Codespaces → `out/faktaverse-final.mp4`**

Gaya visual mengacu pada video referensi: bar judul putih di atas, kartu foto miring/mengambang, label merah blok ("RIGHT UNDER"), stiker + starburst di belakang cutout, teks raksasa dengan blur/outline, transisi cepat.

> ⚠️ **Status verifikasi jujur.** Kode ditulis di lingkungan tanpa akses internet, sehingga `npm install`, build, preview, dan render MP4 **belum pernah dijalankan** oleh pembuatnya. Yang sudah dites: mesin edit otomatis (6 preset, deterministik, durasi, variasi), deteksi beat (120 BPM pada musik sintetis terdeteksi benar), parser SRT/naskah, pembuat suara & proyek demo. Lihat bagian "Langkah verifikasi pertama" — jalankan lebih dulu, dan jika ada error kirim pesannya untuk diperbaiki. `package-lock.json` akan dibuat oleh `npm install` pertama (commit ke GitHub setelahnya).

## Mulai cepat (GitHub Codespaces)

```bash
npm install            # juga membuat efek suara + proyek demo (postinstall)
npx remotion browser ensure   # jika Chrome Headless belum ada
npm run preview        # editor (5173) + API (3001)
```

Di Codespaces buka tab **Ports**: forward **5173** (editor) dan **3001** (API). Visibility *Private* cukup bila kamu membuka dari akun yang sama; Vite memproksi `/api` dan `/files` ke 3001 sehingga browser HP cukup membuka URL port 5173.

Setelah proyek siap dan tersimpan (indikator "Tersimpan"), hentikan preview atau buka terminal kedua:

```bash
npm run render                 # proyek yang terakhir disimpan
npm run render -- <id-proyek>  # proyek tertentu
npm run render:demo            # proyek demo 30 detik
RENDER_CONCURRENCY=1 npm run render   # jika memori kurang
```
Hasil: `out/faktaverse-final.mp4` (H.264 + AAC, 1080×1920, 30fps). Unduh via Explorer → klik kanan → Download. **Render tidak pernah dimulai otomatis.**

## Langkah verifikasi pertama
1. `npm install` → `npm run typecheck` → `npm run build`
2. `npm run test:engine` (tes mesin edit tanpa dependensi berat)
3. `npm run render:demo` → buka `out/faktaverse-final.mp4`; periksa tidak ada frame hitam, gambar hilang, audio hilang.
4. `npm run preview`, buat proyek, unggah media, AUTOMATIC EDIT, Preview, simpan, `npm run render`.

## Fitur
- **6 preset** berbeda (Brainrot, Meme, Cinematic Documentary, Fast-Paced History, Mystery, Hybrid): bobot layout/kamera/transisi, grade warna, grain, vignette, shake, glitch.
- **Mesin edit otomatis** (`src/engine/autoEdit.ts`): titik potong dari beat musik / batas kalimat narasi / grid tempo; memilih layout berdasarkan aspek & resolusi gambar; kamera dan transisi tidak berulang berurutan; SFX per transisi; seed untuk "Regenerate".
- **11 layout**: hero, blur-bg, double, triple, floating, tilted, cutout, PiP, multilayer parallax, typography penuh, poster.
- **Kamera**: zoom in/out, punch, shake, pan H/V, rotate, parallax, whip. **Visual**: motion blur, RGB split/glitch, flash, grain, vignette, color grade. Semuanya fungsi murni dari frame (deterministik).
- **Tipografi kinetik**: pop, bounce, shake, rotate, sticker, per-karakter, per-kata, outline, block, label; highlight kata kunci; auto-fit ukuran font di area aman 9:16.
- **Audio**: volume, fade in/out, ducking musik saat narasi, normalisasi loudness (ffmpeg loudnorm), deteksi beat, SFX sintetis (whoosh, impact, bass, pop, glitch).
- **Preview** = komposisi Remotion yang sama dengan render (`@remotion/player`), termasuk preview per scene.
- **Penyimpanan proyek** di `projects/<id>/project.json` + `assets/` (tulis atomik + `.bak`, autosave, pemulihan setelah reload), impor/ekspor konfigurasi.

## Mode & fitur opsional (tanpa key tetap jalan)
| Fitur | Dengan key | Tanpa key |
|---|---|---|
| Transkripsi narasi | `OPENAI_API_KEY` (Whisper, timestamp kata) | Tempel naskah (timing **perkiraan**, ditandai `estimated`) atau SRT (timing kalimat nyata) |
| Kata kunci subtitle | `ANTHROPIC_API_KEY` (divalidasi harus ada di teks) | Heuristik lokal |
| Portrait cutout | `REMOVEBG_API_KEY` | Layout `cutout` memakai kartu foto biasa (tidak berpura-pura memotong) |

## Batasan yang diketahui (tidak disembunyikan)
- Tidak ada pencocokan gambar↔isi narasi secara semantik (butuh model vision); gambar dipakai sesuai urutan yang kamu atur.
- Tanpa narasi, teks hanya yang kamu tulis (baris per scene + judul bar). Tidak ada teks/narasi karangan.
- Ducking berbasis durasi narasi (musik turun selama narasi, naik setelah selesai), bukan deteksi jeda bicara.
- Efek RGB-split/glitch merender beberapa salinan layer hanya selama beberapa frame; di HP preview bisa patah, hasil render tetap benar.
- Font Anton & Montserrat dimuat dari paket npm `@fontsource` (lisensi OFL). Jika gagal dimuat, memakai font cadangan.
- Ekspor proyek hanya konfigurasi, bukan file aset.
- Klip video didukung sebagai sumber visual (audio klip dibisukan).

## Struktur
```
src/engine      tipe, preset, mesin edit otomatis, subtitle
src/remotion    komposisi (Main, SceneView, layouts) — dipakai preview & render
src/effects     kamera, transisi, overlay (grain, vignette, glitch, flash)
src/typography  tipografi kinetik, caption, font
src/components  UI editor (Dashboard, Media, Gaya, Scene, Preview, Atur, Ekspor)
server          Express: upload, proses gambar/audio, beat, AI opsional
scripts         render.ts, setup.ts (suara+demo), synth.ts, test-engine.ts
projects/demo   proyek contoh 30 detik (aset lokal sintetis)
```

## Troubleshooting
- *Upload gagal / API tidak terjangkau*: pastikan port 3001 berjalan dan di-forward.
- *Render kehabisan memori*: `RENDER_CONCURRENCY=1`, kurangi durasi/jumlah aset.
- *Aset hilang*: render berhenti dengan pesan file mana yang hilang; unggah ulang di tab Media.
- *Font tidak tampil di render*: periksa log bundler; komposisi tetap jalan dengan font cadangan.
