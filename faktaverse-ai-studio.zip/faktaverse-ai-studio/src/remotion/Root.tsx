import React from 'react';
import { Composition } from 'remotion';
import { HEIGHT, newProject, totalFrames, WIDTH, type Project } from '../engine/types';
import { Main, type MainProps } from './Main';

const empty: MainProps = { project: newProject('empty', 'empty') };

export const Root: React.FC = () => (
  <Composition
    id="Faktaverse"
    component={Main as React.FC<Record<string, unknown>>}
    width={WIDTH}
    height={HEIGHT}
    fps={30}
    durationInFrames={30}
    defaultProps={empty as unknown as Record<string, unknown>}
    calculateMetadata={({ props }) => {
      const p = (props as unknown as MainProps).project as Project;
      return { durationInFrames: totalFrames(p), fps: p.fps || 30, width: WIDTH, height: HEIGHT };
    }}
  />
);
